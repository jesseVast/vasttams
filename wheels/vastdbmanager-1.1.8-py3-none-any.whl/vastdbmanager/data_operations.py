"""Data operations for VastDBManager"""

import logging
import time
import uuid
import asyncio
from typing import List, Dict, Any, Optional
import pyarrow as pa

# Try to import vastdb, but make it optional
try:
    import vastdb
    VASTDB_AVAILABLE = True
except ImportError:
    VASTDB_AVAILABLE = False
    vastdb = None

# Configuration constants
DEFAULT_BATCH_SIZE = 100
DEFAULT_MAX_WORKERS = 4
PARALLEL_THRESHOLD = 10
DEFAULT_MAX_RETRIES = 3

logger = logging.getLogger(__name__)


class DataOperations:
    """Handles data CRUD operations (insert, update, delete, query)"""
    
    def __init__(self, connection_manager, cache_manager,
                 batch_size: int = DEFAULT_BATCH_SIZE, max_retries: int = DEFAULT_MAX_RETRIES):
        """
        Initialize data operations with required components
        
        Args:
            connection_manager: Connection manager instance
            cache_manager: Cache manager instance
            batch_size: Default batch size for operations
            max_retries: Maximum retry attempts for failed operations
        """
        self.connection_manager = connection_manager
        self.cache_manager = cache_manager
        self.batch_size = batch_size
        self.max_retries = max_retries
    
    def insert_single_record(self, table_name: str, data: Dict[str, Any]):
        """Insert a single Python dictionary record into a table"""
        try:
            logger.debug("DataOps insert_single_record called with data: %s", data)
            logger.debug("DataOps insert_single_record data types: %s", {k: type(v) for k, v in data.items()})
            
            if not self.connection_manager.is_connected():
                raise RuntimeError("Not connected to VAST database")
            
            start_time = time.time()
            
            # Get the table schema from cache or database
            schema = self.cache_manager.get_table_columns(table_name)
            if schema is None:
                # If not cached, fetch from database
                connection = self.connection_manager.get_connection()
                bucket = self.connection_manager.get_bucket()
                schema_name = self.connection_manager.get_schema()
                
                with connection.transaction() as tx:
                    bucket_obj = tx.bucket(bucket)
                    schema_obj = bucket_obj.schema(schema_name)
                    vast_table = schema_obj.table(table_name)
                    schema = vast_table.columns()
                    # Cache the schema
                    stats = vast_table.get_stats()
                    total_rows = getattr(stats, 'total_rows', 0) or 0
                    self.cache_manager.update_table_cache(table_name, schema, total_rows)
            
            # Filter schema to only include columns present in data
            columns = list(data.keys())
            schema_fields = [
                field for field in schema
                if field.name in columns
            ]
            
            # Convert single record to list format for RecordBatch creation
            converted_data = {}
            logger.debug(f"Original data for {table_name}: {data}")
            logger.debug(f"Original data types for {table_name}: {[(k, type(v)) for k, v in data.items()]}")
            
            for col, value in data.items():
                # Convert UUIDs to strings recursively
                original_value = value
                
                # Handle SegmentDuration before generic conversion
                if hasattr(value, '__class__') and value.__class__.__name__ == 'SegmentDuration':
                    # Convert SegmentDuration objects to string representation
                    converted_data[col] = [f"{value.numerator}/{value.denominator}"]
                    logger.debug(f"Column {col} converted from SegmentDuration to string: {converted_data[col]}")
                    continue

                # Generic conversions (UUIDs, nested types)
                value = self._convert_uuids_to_strings(value)
                logger.debug(f"Column {col}: {original_value} -> {value} (type: {type(value)})")
                
                if isinstance(value, (dict, list)):
                    # Convert nested dictionaries and lists to JSON strings
                    import json
                    converted_data[col] = [json.dumps(value)]
                    logger.debug(f"Column {col} converted to JSON string: {converted_data[col]}")
                else:
                    converted_data[col] = [value]
                    logger.debug(f"Column {col} wrapped in list: {converted_data[col]} (type: {type(converted_data[col][0])})")
            
            logger.debug(f"Converted data for {table_name}: {converted_data}")
            
            # Create record batch (VAST expects RecordBatch, not Table)
            logger.debug(f"Schema fields for {table_name}: {schema_fields}")
            logger.debug(f"Schema field types: {[(f.name, f.type) for f in schema_fields]}")
            logger.debug(f"Final converted data: {converted_data}")
            logger.debug(f"Final converted data types: {[(k, type(v[0]) if v else None) for k, v in converted_data.items()]}")
            
            record_batch = pa.RecordBatch.from_pydict(converted_data, schema=pa.schema(schema_fields))
            
            connection = self.connection_manager.get_connection()
            bucket = self.connection_manager.get_bucket()
            schema_name = self.connection_manager.get_schema()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                schema_obj = bucket_obj.schema(schema_name)
                vast_table = schema_obj.table(table_name)
                
                vast_table.insert(record_batch)
            
            execution_time = time.time() - start_time
            
            
            logger.debug(f"Inserted 1 row into '{table_name}' in {execution_time:.3f}s")
            
        except Exception as e:
            execution_time = time.time() - start_time if 'start_time' in locals() else 0
            
            logger.error(f"Error inserting data into table {table_name}: {e}")
            raise
    
    def insert_record_list(self, table_name: str, data: List[Dict[str, Any]]):
        """Insert a list of Python dictionary records into a table"""
        try:
            if not self.connection_manager.is_connected():
                raise RuntimeError("Not connected to VAST database")
            
            start_time = time.time()
            
            connection = self.connection_manager.get_connection()
            bucket = self.connection_manager.get_bucket()
            schema_name = self.connection_manager.get_schema()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                schema_obj = bucket_obj.schema(schema_name)
                table = schema_obj.table(table_name)
                table.insert_pylist(data)
            
            execution_time = time.time() - start_time
            
            
            logger.debug(f"Inserted {len(data)} rows into table {table_name} in {execution_time:.3f}s")
            
        except Exception as e:
            execution_time = time.time() - start_time if 'start_time' in locals() else 0
            
            
            logger.error(f"Error inserting data into table {table_name}: {e}")
            raise
    
    def update(self, table_name: str, data: Dict[str, List[Any]], predicate: Optional[Any] = None):
        """Update data in a table using VAST's native UPDATE capability"""
        try:
            if predicate is None:
                logger.warning(f"Update operation requires a predicate for table {table_name}")
                return 0
            
            # Get the table schema upfront for validation
            table_schema = self.cache_manager.get_table_columns(table_name)
            if table_schema is None:
                logger.error(f"Could not get schema for table {table_name}")
                return 0
            
            # Validate column names upfront before doing any expensive operations
            columns = list(data.keys())
            available_columns = [f.name for f in table_schema]
            invalid_columns = [col for col in columns if col not in available_columns]
            
            if invalid_columns:
                logger.error(f"Invalid columns for table {table_name}: {invalid_columns}")
                logger.error(f"Available columns: {available_columns}")
                return 0
            
            logger.debug(f"Updating {len(columns)} columns in table {table_name}")
            
            # Query with predicate to get rows to update (with row IDs)
            matching_rows = self.query_with_predicates(table_name, predicate, include_row_ids=True)
            
            if not matching_rows:
                logger.warning(f"No rows found matching predicate for update in table {table_name}")
                return 0
            
            # Extract row IDs from the result
            if hasattr(matching_rows, 'to_pydict'):
                row_data = matching_rows.to_pydict()
            else:
                row_data = matching_rows
            
            if '$row_id' not in row_data:
                logger.error(f"Row IDs not found in query result")
                return 0
            
            row_ids = row_data['$row_id']
            num_rows = len(row_ids)
            logger.info(f"Found {num_rows} rows to update")
            
            # Build update schema with $row_id + columns being updated
            update_schema = [pa.field('$row_id', pa.uint64())]
            
            for field in table_schema:
                if field.name in columns:
                    update_schema.append(field)
            
            # Create update data with new values + row IDs
            update_data = {}
            for column in columns:
                update_data[column] = []
            
            # Repeat the update values for each row
            for _ in range(num_rows):
                for column in columns:
                    if isinstance(data[column], list):
                        # Use first value if it's a list
                        update_data[column].append(data[column][0] if data[column] else None)
                    else:
                        # Use the value directly
                        update_data[column].append(data[column])
            
            # Add row IDs
            update_data['$row_id'] = row_ids
            
            # Create RecordBatch and update the table
            records = pa.RecordBatch.from_pydict(update_data, schema=pa.schema(update_schema))
            
            connection = self.connection_manager.get_connection()
            bucket = self.connection_manager.get_bucket()
            schema_name = self.connection_manager.get_schema()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                schema_obj = bucket_obj.schema(schema_name)
                vast_table = schema_obj.table(table_name)
                
                vast_table.update(records)
                logger.info(f"Updated {num_rows} rows in '{table_name}'")
                return num_rows
                
        except Exception as e:
            logger.error(f"Failed to update table {table_name}: {e}")
            raise
    
    def delete(self, table_name: str, predicate: Optional[Any] = None):
        """Delete data from a table using VAST's native DELETE capability"""
        try:
            if predicate is None:
                logger.warning(f"Delete operation requires a predicate for table {table_name}")
                return 0
            
            # Note: Complex delete operations with predicates now require Trino
            # This method is kept for simple delete operations only
            logger.warning(f"Complex delete operations with predicates now require Trino query system. "
                          f"Use VastDBManager.query(table).delete().where(condition).execute() instead.")
            return 0
                    
        except Exception as e:
            logger.error(f"Error deleting from table {table_name}: {e}")
            raise
    
    def _create_basic_query_config(self, table_name: str):
        """Create a basic dict of query options; let VAST handle optimization."""
        if not VASTDB_AVAILABLE:
            logger.debug("vastdb not available, using empty query options")
            return {}
        try:
            # Keep options minimal; VAST handles most optimization automatically
            config: Dict[str, Any] = {
                "use_semi_sorted_projections": True,
            }
            logger.debug(f"Created basic query options for {table_name}")
            return config
        except Exception as e:
            logger.debug(f"Failed to create basic query options: {e}; using empty options")
            return {}
    
    def query_with_predicates(self, table_name: str, predicates: Optional[Any] = None, 
                             columns: Optional[List[str]] = None, limit: Optional[int] = None,
                             include_row_ids: bool = False):
        """Query data from a table with optional predicates using VAST's query capabilities"""
        try:
            if not self.connection_manager.is_connected():
                logger.warning(f"Cannot query table {table_name}: not connected")
                return None
            
            connection = self.connection_manager.get_connection()
            bucket = self.connection_manager.get_bucket()
            schema_name = self.connection_manager.get_schema()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                schema_obj = bucket_obj.schema(schema_name)
                table = schema_obj.table(table_name)
                
                # Create query configuration
                query_config = self._create_basic_query_config(table_name)
                if query_config is None:
                    logger.warning(f"Could not create query config for {table_name}, using basic query")
                    query_config = {}
                
                # Apply predicates if provided
                if predicates is not None:
                    if hasattr(predicates, 'to_expr'):
                        # Ibis expression
                        query_config['predicate'] = predicates.to_expr()
                    elif isinstance(predicates, dict):
                        # Dictionary predicates - convert to VAST format
                        query_config['predicate'] = predicates
                    else:
                        # Direct predicate
                        query_config['predicate'] = predicates
                
                # Apply column selection
                if columns is not None:
                    query_config['columns'] = columns
                
                # Apply limit
                if limit is not None:
                    query_config['limit'] = limit
                
                # Execute query
                result = table.query(query_config)
                
                # Convert to PyArrow Table if needed
                if hasattr(result, 'to_arrow'):
                    result = result.to_arrow()
                
                logger.debug(f"Query executed on {table_name}: {len(result) if hasattr(result, '__len__') else 'unknown'} rows")
                return result
                
        except Exception as e:
            logger.error(f"Error querying table {table_name}: {e}")
            return None

    def _convert_uuids_to_strings(self, obj):
        """Recursively convert UUID objects and SegmentDuration objects to strings in any data structure"""
        if isinstance(obj, uuid.UUID):
            return str(obj)
        elif hasattr(obj, '__class__') and obj.__class__.__name__ == 'SegmentDuration':
            return f"{obj.numerator}/{obj.denominator}"
        elif isinstance(obj, dict):
            return {key: self._convert_uuids_to_strings(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_uuids_to_strings(item) for item in obj]
        else:
            return obj
    
    def _insert_column_batch(self, table_name: str, data: Dict[str, List[Any]]):
        """Insert data from a Python dictionary with row pooling and cache updates"""
        try:
            start_time = time.time()
            
            # Get the table schema from cache or database
            schema = self.cache_manager.get_table_columns(table_name)
            if schema is None:
                # If not cached, fetch from database
                connection = self.connection_manager.get_connection()
                bucket = self.connection_manager.get_bucket()
                schema_name = self.connection_manager.get_schema()
                
                with connection.transaction() as tx:
                    bucket_obj = tx.bucket(bucket)
                    schema_obj = bucket_obj.schema(schema_name)
                    vast_table = schema_obj.table(table_name)
                    schema = vast_table.columns()
                    # Cache the schema
                    stats = vast_table.get_stats()
                    total_rows = getattr(stats, 'total_rows', 0) or 0
                    self.cache_manager.update_table_cache(table_name, schema, total_rows)
            
            # Filter schema to only include columns present in data
            columns = list(data.keys())
            schema_fields = [
                field for field in schema
                if field.name in columns
            ]
            
            # Create record batch (VAST expects RecordBatch, not Table)
            # Convert UUID objects and complex types to strings for PyArrow compatibility
            converted_data = {}
            for col, values in data.items():
                converted_values = []
                for value in values:
                    # First convert any UUIDs to strings recursively
                    value = self._convert_uuids_to_strings(value)
                    
                    if isinstance(value, (dict, list)):
                        # Convert nested dictionaries and lists to JSON strings
                        import json
                        converted_values.append(json.dumps(value))
                    else:
                        converted_values.append(value)
                converted_data[col] = converted_values
            
            record_batch = pa.RecordBatch.from_pydict(converted_data, schema=pa.schema(schema_fields))
            
            num_records = len(record_batch)
            logger.debug(f"Inserting {num_records} rows into '{table_name}'")
            
            # Insert the data
            connection = self.connection_manager.get_connection()
            bucket = self.connection_manager.get_bucket()
            schema_name = self.connection_manager.get_schema()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                schema_obj = bucket_obj.schema(schema_name)
                vast_table = schema_obj.table(table_name)
                
                vast_table.insert(record_batch)
                
            execution_time = time.time() - start_time
            
            # Update cache with new row count
            current_stats = self.cache_manager.get_table_stats(table_name)
            current_rows = 0
            if current_stats and isinstance(current_stats, dict):
                current_rows = current_stats.get('total_rows', 0)
                # Handle nested dictionary case (defensive programming)
                if isinstance(current_rows, dict):
                    current_rows = current_rows.get('total_rows', 0)
                # Ensure we have a valid number before calling int()
                if current_rows is not None and current_rows != '':
                    try:
                        current_rows = int(current_rows)
                    except (ValueError, TypeError):
                        current_rows = 0
                else:
                    current_rows = 0
            
            new_total_rows = current_rows + num_records
            
            # Update cache with new stats
            self.cache_manager.update_table_cache(table_name, schema, new_total_rows)
            
            
            logger.info(f"Inserted {num_records} rows into '{table_name}' in {execution_time:.3f}s")
            logger.debug(f"Updated cache: {current_rows} -> {new_total_rows} total rows")
            
            return num_records
                
        except Exception as e:
            execution_time = time.time() - start_time if 'start_time' in locals() else 0
            
            
            logger.error(f"Failed to insert data into table '{table_name}': {e}")
            raise
    
    def insert(self, table_name: str, data: Dict[str, List[Any]]):
        """Backward compatibility method - alias for _insert_column_batch"""
        return self._insert_column_batch(table_name, data)
    
    def select(self, table_name: str, predicate: Optional[Any] = None, 
               output_by_row: bool = False, columns: Optional[List[str]] = None):
        """Backward compatibility method - alias for query_with_predicates"""
        # Pass predicates directly - let query_with_predicates handle the type
        # Ibis predicates will be used directly, dictionaries will be converted
        
        result = self.query_with_predicates(
            table_name=table_name,
            predicates=predicate,
            columns=columns
        )
        
        # Convert PyArrow Table to dict if needed
        if result is not None and hasattr(result, 'to_pydict'):
            result = result.to_pydict()
        
        if output_by_row and result is not None:
            # Convert column-oriented result to row-oriented format
            if len(result) > 0:
                num_rows = len(next(iter(result.values())))
                return [
                    {col: result[col][i] for col in result.keys()}
                    for i in range(num_rows)
                ]
        
        return result
    
    # Async Methods
    async def insert_single_record_async(self, table_name: str, data: Dict[str, Any]):
        """Insert a single Python dictionary record into a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.insert_single_record, table_name, data)
    
    async def insert_record_list_async(self, table_name: str, data: List[Dict[str, Any]]):
        """Insert a list of Python dictionary records into a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.insert_record_list, table_name, data)
    
    async def update_async(self, table_name: str, data: Dict[str, List[Any]], predicate: Optional[Any] = None):
        """Update data in a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.update, table_name, data, predicate)
    
    async def delete_async(self, table_name: str, predicate: Optional[Any] = None):
        """Delete data from a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.delete, table_name, predicate)
    
    async def query_with_predicates_async(self, table_name: str, predicates: Optional[Any] = None, 
                                         columns: Optional[List[str]] = None, limit: Optional[int] = None,
                                         include_row_ids: bool = False):
        """Query data from a table with optional predicates asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.query_with_predicates, 
                                        table_name, predicates, columns, limit, include_row_ids)
    
    async def _insert_column_batch_async(self, table_name: str, data: Dict[str, List[Any]]):
        """Insert data from a Python dictionary asynchronously with row pooling and cache updates"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._insert_column_batch, table_name, data)
    
    async def insert_async(self, table_name: str, data: Dict[str, List[Any]]):
        """Backward compatibility method - alias for _insert_column_batch_async"""
        return await self._insert_column_batch_async(table_name, data)
    
    async def select_async(self, table_name: str, predicate: Optional[Any] = None, 
                          output_by_row: bool = False, columns: Optional[List[str]] = None):
        """Backward compatibility method - alias for query_with_predicates_async"""
        result = await self.query_with_predicates_async(
            table_name=table_name,
            predicates=predicate,
            columns=columns
        )
        
        # Convert PyArrow Table to dict if needed
        if result is not None and hasattr(result, 'to_pydict'):
            result = result.to_pydict()
        
        if output_by_row and result is not None:
            # Convert column-oriented result to row-oriented format
            if len(result) > 0:
                num_rows = len(next(iter(result.values())))
                return [
                    {col: result[col][i] for col in result.keys()}
                    for i in range(num_rows)
                ]
        
        return result
