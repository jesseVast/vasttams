"""
S3 Client - Main Interface

This module provides the main S3Client interface that handles all S3 operations
including connection management, basic CRUD, multipart uploads, object management,
and tagging operations.
"""

import logging
import asyncio
from typing import Optional, Dict, Any, List, TYPE_CHECKING
from pathlib import Path
import boto3
import aioboto3
from botocore.exceptions import ClientError, NoCredentialsError

if TYPE_CHECKING:
    from aioboto3 import Session

from .multipart import S3MultipartUploader
from .objects import S3ObjectManager
from .tags import S3ObjectTagger
from .config import S3Config

logger = logging.getLogger(__name__)


class S3Client:
    """
    Main S3 client that provides a unified interface to all S3 operations
    
    This class composes all S3 services and provides a high-level API for:
    - Basic CRUD operations
    - Multipart uploads for large files
    - Object management and listing
    - Object tagging and tag-based search
    - Configuration management
    """
    
    def __init__(self, config: Optional[S3Config] = None, **kwargs):
        """
        Initialize S3 client
        
        Args:
            config: S3Config instance (optional)
            **kwargs: Additional configuration parameters
        """
        if config is None:
            config = S3Config(**kwargs)
        
        self.config = config
        
        # Store connection parameters
        self.endpoint_url = config.endpoint_url
        self.bucket_name = config.bucket_name  # Can be None for bucketless operations
        self.key_prefix = config.key_prefix.rstrip('/') if config.key_prefix else ""
        self.headers = config.headers or {}
        
        # Initialize S3 client
        try:
            session = boto3.Session()
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug("Creating S3 client with endpoint: %s, region: us-east-1", self.endpoint_url)
            
            # Prepare client configuration
            client_kwargs = {
                'service_name': 's3',
                'endpoint_url': self.endpoint_url,
                'aws_access_key_id': config.access_key or "",
                'aws_secret_access_key': config.secret_key or "",
                'use_ssl': config.use_ssl,
                'region_name': 'us-east-1'
            }
            
            # Add custom headers if provided
            if config.headers:
                from botocore.config import Config
                client_kwargs['config'] = Config(
                    signature_version='s3v4',
                    s3={
                        'addressing_style': 'path'
                    }
                )
                # Note: boto3 doesn't directly support custom headers in client creation
                # Headers will be applied per request in the methods that need them
                logger.debug("Custom headers configured: %s", config.headers)
            
            self.s3_client = session.client(**client_kwargs)
            
            logger.debug("Created S3 client: %s", self.s3_client)
            
            # Only ensure bucket exists if bucket_name is provided
            if self.bucket_name:
                self._ensure_bucket_exists()
                logger.info("S3Client initialized with endpoint: %s, bucket: %s", 
                           self.endpoint_url, self.bucket_name)
            else:
                logger.info("S3Client initialized with endpoint: %s (no bucket)", 
                           self.endpoint_url)
        except Exception as e:
            logger.error("Failed to initialize S3Client: %s", e)
            import traceback
            logger.error("Traceback: %s", traceback.format_exc())
            raise
        
        # Initialize specialized services
        self.multipart = S3MultipartUploader(
            s3_client=self,
            chunk_size=config.chunk_size,
            max_concurrent_parts=config.max_concurrent_parts
        )
        
        self.objects = S3ObjectManager(s3_client=self)
        self.tags = S3ObjectTagger(s3_client=self)
        
        logger.info("S3Client initialized with bucket: %s, prefix: %s", 
                   config.bucket_name, config.key_prefix)
    
    def _build_key(self, key: str) -> str:
        """
        Build full S3 key with prefix.
        
        Args:
            key: The key to prefix
            
        Returns:
            Full key with prefix
        """
        if not self.key_prefix:
            return key
        return f"{self.key_prefix}/{key.lstrip('/')}"
    
    def _apply_headers(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Apply custom headers to S3 request parameters.
        
        Args:
            kwargs: S3 request parameters
            
        Returns:
            Updated parameters with custom headers
        """
        if self.headers:
            # Add custom headers to the request
            if 'ExtraArgs' not in kwargs:
                kwargs['ExtraArgs'] = {}
            if 'Metadata' not in kwargs['ExtraArgs']:
                kwargs['ExtraArgs']['Metadata'] = {}
            
            # Add custom headers as metadata or directly to ExtraArgs
            for header_key, header_value in self.headers.items():
                # Some headers need special handling
                if header_key.lower() == 'content-type':
                    kwargs['ExtraArgs']['ContentType'] = header_value
                elif header_key.lower() == 'cache-control':
                    kwargs['ExtraArgs']['CacheControl'] = header_value
                elif header_key.lower() == 'content-disposition':
                    kwargs['ExtraArgs']['ContentDisposition'] = header_value
                elif header_key.lower() == 'content-encoding':
                    kwargs['ExtraArgs']['ContentEncoding'] = header_value
                elif header_key.lower() == 'expires':
                    kwargs['ExtraArgs']['Expires'] = header_value
                else:
                    # Add as custom metadata
                    kwargs['ExtraArgs']['Metadata'][f'x-custom-{header_key}'] = header_value
        
        return kwargs
    
    def _ensure_bucket_exists(self):
        """Ensure the S3 bucket exists, create if it doesn't"""
        try:
            self.s3_client.head_bucket(Bucket=self.bucket_name)
            logger.debug("Bucket '%s' already exists", self.bucket_name)
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == '404':
                logger.debug("Bucket '%s' does not exist, creating...", self.bucket_name)
                try:
                    self.s3_client.create_bucket(Bucket=self.bucket_name)
                    logger.info("Created bucket '%s'", self.bucket_name)
                except Exception as create_error:
                    logger.error("Failed to create bucket '%s': %s", self.bucket_name, create_error)
                    raise
            elif error_code == '403':
                # S3 endpoint doesn't support head_bucket operation, skip check
                logger.warning("S3 endpoint doesn't support head_bucket operation, skipping bucket check for '%s'", self.bucket_name)
            else:
                logger.error("Error checking bucket '%s': %s", self.bucket_name, e)
                raise
        except NoCredentialsError:
            logger.error("No AWS credentials found")
            raise
        except Exception as e:
            logger.error("Unexpected error with bucket '%s': %s", self.bucket_name, e)
            raise
    
    # Core Operations (now implemented directly)
    def upload_object(self, key: str, data: bytes, content_type: str = "application/octet-stream", bucket: Optional[str] = None) -> bool:
        """Upload data to S3.
        
        Args:
            key: Object key
            data: Object data
            content_type: MIME type of the object
            bucket: Bucket name. If None, uses bucket from config (if available)
        
        Raises:
            ValueError: If no bucket is specified and config has no default bucket
        """
        target_bucket = bucket or self.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_key = self._build_key(key)
            logger.debug("Uploading object to S3: %s (full key: %s, bucket: %s)", key, full_key, target_bucket)
            
            # Prepare upload parameters
            upload_params = {
                'Bucket': target_bucket,
                'Key': full_key,
                'Body': data,
                'ContentType': content_type
            }
            
            # Apply custom headers
            upload_params = self._apply_headers(upload_params)
            
            # Use single PUT for smaller files
            self.s3_client.put_object(**upload_params)
            logger.debug("Uploaded object: %s (%d bytes)", key, len(data))
            return True
        except Exception as e:
            logger.error("Failed to upload object %s: %s", key, e)
            return False
    
    def download_object(self, key: str, bucket: Optional[str] = None) -> Optional[bytes]:
        """Download data from S3.
        
        Args:
            key: Object key
            bucket: Bucket name. If None, uses bucket from config (if available)
        
        Raises:
            ValueError: If no bucket is specified and config has no default bucket
        """
        target_bucket = bucket or self.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_key = self._build_key(key)
            response = self.s3_client.get_object(Bucket=target_bucket, Key=full_key)
            data = response['Body'].read()
            logger.debug("Downloaded object: %s (%d bytes)", key, len(data))
            return data
        except Exception as e:
            logger.error("Failed to download object %s: %s", key, e)
            return None
    
    def delete_object(self, key: str, bucket: Optional[str] = None) -> bool:
        """Delete object from S3.
        
        Args:
            key: Object key
            bucket: Bucket name. If None, uses bucket from config (if available)
        
        Raises:
            ValueError: If no bucket is specified and config has no default bucket
        """
        target_bucket = bucket or self.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_key = self._build_key(key)
            self.s3_client.delete_object(Bucket=target_bucket, Key=full_key)
            logger.debug("Deleted object: %s", key)
            return True
        except Exception as e:
            logger.error("Failed to delete object %s: %s", key, e)
            return False
    
    def object_exists(self, key: str, bucket: Optional[str] = None) -> bool:
        """Check if object exists in S3.
        
        Args:
            key: Object key
            bucket: Bucket name. If None, uses bucket from config (if available)
        
        Raises:
            ValueError: If no bucket is specified and config has no default bucket
        """
        target_bucket = bucket or self.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_key = self._build_key(key)
            self.s3_client.head_object(Bucket=target_bucket, Key=full_key)
            return True
        except ClientError as e:
            if e.response['Error']['Code'] == '404':
                return False
            raise
        except Exception as e:
            logger.error("Error checking if object %s exists: %s", key, e)
            return False
    
    def get_object_metadata(self, key: str, bucket: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Get object metadata.
        
        Args:
            key: Object key
            bucket: Bucket name. If None, uses bucket from config (if available)
        
        Raises:
            ValueError: If no bucket is specified and config has no default bucket
        """
        target_bucket = bucket or self.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_key = self._build_key(key)
            response = self.s3_client.head_object(Bucket=target_bucket, Key=full_key)
            metadata = {
                'content_length': response.get('ContentLength'),
                'content_type': response.get('ContentType'),
                'last_modified': response.get('LastModified'),
                'etag': response.get('ETag'),
                'metadata': response.get('Metadata', {}),
                'storage_class': response.get('StorageClass'),
                'server_side_encryption': response.get('ServerSideEncryption')
            }
            logger.debug("Retrieved metadata for object: %s (bucket: %s)", key, target_bucket)
            return metadata
        except Exception as e:
            logger.error("Failed to get metadata for object %s: %s", key, e)
            return None
    
    # Multipart Operations (delegated to S3MultipartUploader)
    def upload_file(self, file_path: str, key: str, content_type: str = "application/octet-stream") -> bool:
        """Upload file using multipart upload for large files"""
        return self.multipart.upload_file(file_path, key, content_type)
    
    def upload_large_object(self, key: str, data: bytes, content_type: str = "application/octet-stream") -> bool:
        """Upload large data using multipart upload"""
        return self.multipart.upload_object(key, data, content_type)
    
    # Object Management (delegated to S3ObjectManager)
    def list_objects(self, prefix: str = "", max_keys: int = 1000, bucket: Optional[str] = None) -> List[str]:
        """List objects in S3"""
        return self.objects.list_objects(prefix, max_keys, bucket=bucket)
    
    def list_objects_with_metadata(self, prefix: str = "", max_keys: int = 1000, bucket: Optional[str] = None) -> List[Dict[str, Any]]:
        """List objects with metadata"""
        return self.objects.list_objects_with_metadata(prefix, max_keys, bucket=bucket)
    
    def copy_object(self, source_key: str, destination_key: str, bucket: Optional[str] = None) -> bool:
        """Copy object within bucket.
        
        Args:
            source_key: Source object key
            destination_key: Destination object key
            bucket: Bucket name. If None, uses bucket from config (if available)
        
        Raises:
            ValueError: If no bucket is specified and config has no default bucket
        """
        target_bucket = bucket or self.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        return self.objects.copy_object(source_key, destination_key, bucket=target_bucket)
    
    def copy_object_to_s3(self, destination_config: 'S3Config', source_key: str, 
                          destination_key: str, metadata: Optional[Dict[str, str]] = None,
                          copy_metadata: bool = True, source_bucket: Optional[str] = None) -> bool:
        """
        Copy object from this S3 instance to another S3 destination.
        
        Uses the source client (self) to initiate the copy operation to the destination.
        This method creates a temporary destination client to perform the copy.
        
        Args:
            destination_config: S3Config for the destination S3 service
            source_key: Key of the source object in this S3 instance
            destination_key: Key for the destination object
            metadata: Optional metadata to set on the destination object
            copy_metadata: Whether to copy metadata from source object
            source_bucket: Source bucket name. If None, uses bucket from config (if available)
            
        Returns:
            bool: True if copy was successful, False otherwise
        """
        source_bucket_name = source_bucket or self.bucket_name
        if not source_bucket_name:
            raise ValueError(
                "No source bucket specified. Either provide 'source_bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            # Build full source key with prefix
            full_source_key = self._build_key(source_key)
            
            # Verify source object exists
            if not self.object_exists(source_key, bucket=source_bucket_name):
                logger.error("Source object does not exist: %s", source_key)
                return False
            
            # Create destination S3 client
            dest_client = S3Client(destination_config)
            
            # Build destination key with destination prefix
            full_dest_key = dest_client._build_key(destination_key)
            
            # Prepare copy source for boto3
            copy_source = {
                'Bucket': source_bucket_name,
                'Key': full_source_key
            }
            
            # Prepare copy parameters
            copy_params = {
                'CopySource': copy_source,
                'Bucket': destination_config.bucket_name,
                'Key': full_dest_key
            }
            
            # Handle metadata
            if metadata or not copy_metadata:
                copy_params['MetadataDirective'] = 'REPLACE'
                copy_params['Metadata'] = metadata or {}
            else:
                copy_params['MetadataDirective'] = 'COPY'
            
            # Perform the copy using destination client
            logger.debug("Copying object from %s:%s to %s:%s", 
                       source_bucket_name, full_source_key,
                       destination_config.bucket_name, full_dest_key)
            
            response = dest_client.s3_client.copy_object(**copy_params)
            
            # Verify copy was successful
            if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                logger.info("Copied object from %s to %s", source_key, destination_key)
                return True
            else:
                logger.error("Copy operation failed with status code: %s", 
                           response['ResponseMetadata']['HTTPStatusCode'])
                return False
                
        except Exception as e:
            logger.error("Failed to copy object %s to destination S3: %s", source_key, e)
            return False
    
    def delete_objects(self, keys: List[str], bucket: Optional[str] = None) -> Dict[str, Any]:
        """Delete multiple objects"""
        return self.objects.delete_objects(keys, bucket=bucket)
    
    def generate_presigned_url(self, key: str, operation: str = "get_object", 
                             expiration: int = 3600, bucket: Optional[str] = None,
                             content_type: Optional[str] = None, 
                             response_content_type: Optional[str] = None,
                             response_content_disposition: Optional[str] = None,
                             extra_params: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """Generate presigned URL for object"""
        return self.objects.generate_presigned_url(
            key, operation, expiration, bucket=bucket, content_type=content_type,
            response_content_type=response_content_type,
            response_content_disposition=response_content_disposition,
            extra_params=extra_params
        )
    
    def get_bucket_info(self, bucket: Optional[str] = None) -> Dict[str, Any]:
        """Get bucket information"""
        return self.objects.get_bucket_info(bucket=bucket)
    
    # Tagging Operations (delegated to S3ObjectTagger)
    def put_object_tags(self, key: str, tags: Dict[str, str], bucket: Optional[str] = None) -> bool:
        """Add or update object tags"""
        return self.tags.put_object_tags(key, tags, bucket=bucket)
    
    def get_object_tags(self, key: str, bucket: Optional[str] = None) -> Optional[Dict[str, str]]:
        """Get object tags"""
        return self.tags.get_object_tags(key, bucket=bucket)
    
    def delete_object_tags(self, key: str, bucket: Optional[str] = None) -> bool:
        """Delete all object tags"""
        return self.tags.delete_object_tags(key, bucket=bucket)
    
    def update_object_tags(self, key: str, tags: Dict[str, str], replace_all: bool = True, bucket: Optional[str] = None) -> bool:
        """Update object tags"""
        return self.tags.update_object_tags(key, tags, replace_all, bucket=bucket)
    
    def list_objects_by_tag(self, tag_key: str, tag_value: Optional[str] = None, prefix: str = "") -> List[str]:
        """List objects by tag"""
        return self.tags.list_objects_by_tag(tag_key, tag_value, prefix)
    
    def list_objects_by_tags(self, tag_filters: Dict[str, str], prefix: str = "") -> List[str]:
        """List objects by multiple tags"""
        return self.tags.list_objects_by_tags(tag_filters, prefix)
    
    def get_tag_statistics(self, prefix: str = "") -> Dict[str, Any]:
        """Get tag statistics"""
        return self.tags.get_tag_statistics(prefix)
    
    # Utility Methods
    def upload_file_with_auto_multipart(self, file_path: str, key: str, 
                                      content_type: str = "application/octet-stream") -> bool:
        """
        Upload file with automatic multipart detection
        
        Args:
            file_path: Path to file
            key: S3 object key
            content_type: MIME type
            
        Returns:
            bool: True if successful
        """
        file_path_obj = Path(file_path)
        if not file_path_obj.exists():
            logger.error("File not found: %s", file_path)
            return False
        
        file_size = file_path_obj.stat().st_size
        
        # Use multipart for large files
        if file_size > self.multipart.DEFAULT_MULTIPART_THRESHOLD:
            logger.debug("Using multipart upload for large file: %s (%d bytes)", file_path, file_size)
            return self.upload_file(file_path, key, content_type)
        else:
            logger.debug("Using single upload for small file: %s (%d bytes)", file_path, file_size)
            # Read file and use regular upload
            with open(file_path, 'rb') as f:
                data = f.read()
            return self.upload_object(key, data, content_type)
    
    def download_file(self, key: str, file_path: str) -> bool:
        """
        Download object to file
        
        Args:
            key: S3 object key
            file_path: Local file path
            
        Returns:
            bool: True if successful
        """
        try:
            data = self.download_object(key)
            if data is None:
                return False
            
            file_path_obj = Path(file_path)
            file_path_obj.parent.mkdir(parents=True, exist_ok=True)
            
            with open(file_path_obj, 'wb') as f:
                f.write(data)
            
            logger.info("Downloaded %s to %s", key, file_path)
            return True
            
        except Exception as e:
            logger.error("Failed to download object %s to %s: %s", key, file_path, e)
            return False
    
    def sync_directory(self, local_dir: str, s3_prefix: str = "", 
                     include_patterns: Optional[List[str]] = None, 
                     exclude_patterns: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Sync local directory to S3
        
        Args:
            local_dir: Local directory path
            s3_prefix: S3 prefix for uploaded files
            include_patterns: File patterns to include
            exclude_patterns: File patterns to exclude
            
        Returns:
            Dict with sync results
        """
        # This is a placeholder for directory sync functionality
        # Implementation would involve walking the directory tree
        # and uploading files based on patterns
        logger.info("Directory sync not yet implemented")
        return {
            'uploaded': [],
            'skipped': [],
            'errors': [],
            'total_files': 0
        }
    
    def get_config(self) -> S3Config:
        """Get current configuration"""
        return self.config
    
    def update_config(self, **kwargs) -> None:
        """Update configuration (requires reinitialization)"""
        logger.warning("Configuration update requires client reinitialization")
        # In a real implementation, this would update the config
        # and reinitialize the services
    
    # Async Methods
    async def _get_async_session(self) -> "Session":
        """Get async boto3 session"""
        session = aioboto3.Session()
        return session
    
    async def upload_object_async(self, key: str, data: bytes, content_type: str = "application/octet-stream", bucket: Optional[str] = None) -> bool:
        """Upload data to S3 asynchronously.
        
        Args:
            key: Object key
            data: Object data
            content_type: MIME type of the object
            bucket: Bucket name. If None, uses bucket from config (if available)
        
        Raises:
            ValueError: If no bucket is specified and config has no default bucket
        """
        target_bucket = bucket or self.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_key = self._build_key(key)
            logger.debug("Uploading object to S3 asynchronously: %s (full key: %s, bucket: %s)", key, full_key, target_bucket)
            
            session = await self._get_async_session()
            # Type annotation to help basedpyright understand the async context manager
            s3_client = session.client(
                's3',
                endpoint_url=self.endpoint_url,
                aws_access_key_id=self.config.access_key or "",
                aws_secret_access_key=self.config.secret_key or "",
                use_ssl=self.config.use_ssl,
                region_name='us-east-1'
            )
            async with s3_client as s3:  # type: ignore[reportGeneralTypeIssues]
                await s3.put_object(
                    Bucket=target_bucket,
                    Key=full_key,
                    Body=data,
                    ContentType=content_type
                )
            
            logger.debug("Successfully uploaded object asynchronously: %s (%d bytes)", key, len(data))
            return True
        except Exception as e:
            logger.error("Failed to upload object %s asynchronously: %s", key, e)
            return False
    
    async def download_object_async(self, key: str, bucket: Optional[str] = None) -> Optional[bytes]:
        """Download data from S3 asynchronously.
        
        Args:
            key: Object key
            bucket: Bucket name. If None, uses bucket from config (if available)
        
        Raises:
            ValueError: If no bucket is specified and config has no default bucket
        """
        target_bucket = bucket or self.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_key = self._build_key(key)
            session = await self._get_async_session()
            # Type annotation to help basedpyright understand the async context manager
            s3_client = session.client(
                's3',
                endpoint_url=self.endpoint_url,
                aws_access_key_id=self.config.access_key or "",
                aws_secret_access_key=self.config.secret_key or "",
                use_ssl=self.config.use_ssl,
                region_name='us-east-1'
            )
            async with s3_client as s3:  # type: ignore[reportGeneralTypeIssues]
                response = await s3.get_object(Bucket=target_bucket, Key=full_key)
                data = await response['Body'].read()
            
            logger.debug("Successfully downloaded object asynchronously: %s (full key: %s, %d bytes)", key, full_key, len(data))
            return data
        except Exception as e:
            logger.error("Failed to download object %s asynchronously: %s", key, e)
            return None
    
    async def delete_object_async(self, key: str, bucket: Optional[str] = None) -> bool:
        """Delete object from S3 asynchronously.
        
        Args:
            key: Object key
            bucket: Bucket name. If None, uses bucket from config (if available)
        
        Raises:
            ValueError: If no bucket is specified and config has no default bucket
        """
        target_bucket = bucket or self.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_key = self._build_key(key)
            session = await self._get_async_session()
            # Type annotation to help basedpyright understand the async context manager
            s3_client = session.client(
                's3',
                endpoint_url=self.endpoint_url,
                aws_access_key_id=self.config.access_key or "",
                aws_secret_access_key=self.config.secret_key or "",
                use_ssl=self.config.use_ssl,
                region_name='us-east-1'
            )
            async with s3_client as s3:  # type: ignore[reportGeneralTypeIssues]
                await s3.delete_object(Bucket=target_bucket, Key=full_key)
            
            logger.debug("Successfully deleted object asynchronously: %s (full key: %s)", key, full_key)
            return True
        except Exception as e:
            logger.error("Failed to delete object %s asynchronously: %s", key, e)
            return False
    
    async def object_exists_async(self, key: str) -> bool:
        """Check if object exists in S3 asynchronously"""
        try:
            full_key = self._build_key(key)
            session = await self._get_async_session()
            # Type annotation to help basedpyright understand the async context manager
            s3_client = session.client(
                's3',
                endpoint_url=self.endpoint_url,
                aws_access_key_id=self.config.access_key or "",
                aws_secret_access_key=self.config.secret_key or "",
                use_ssl=self.config.use_ssl,
                region_name='us-east-1'
            )
            async with s3_client as s3:  # type: ignore[reportGeneralTypeIssues]
                await s3.head_object(Bucket=self.bucket_name, Key=full_key)
            return True
        except ClientError as e:
            if e.response['Error']['Code'] == '404':
                return False
            raise
        except Exception as e:
            logger.error("Error checking if object %s exists asynchronously: %s", key, e)
            return False
    
    async def get_object_metadata_async(self, key: str) -> Optional[Dict[str, Any]]:
        """Get object metadata asynchronously"""
        try:
            full_key = self._build_key(key)
            session = await self._get_async_session()
            # Type annotation to help basedpyright understand the async context manager
            s3_client = session.client(
                's3',
                endpoint_url=self.endpoint_url,
                aws_access_key_id=self.config.access_key or "",
                aws_secret_access_key=self.config.secret_key or "",
                use_ssl=self.config.use_ssl,
                region_name='us-east-1'
            )
            async with s3_client as s3:  # type: ignore[reportGeneralTypeIssues]
                response = await s3.head_object(Bucket=self.bucket_name, Key=full_key)
                metadata = {
                    'content_length': response.get('ContentLength'),
                    'content_type': response.get('ContentType'),
                    'last_modified': response.get('LastModified'),
                    'etag': response.get('ETag'),
                    'metadata': response.get('Metadata', {}),
                    'storage_class': response.get('StorageClass'),
                    'server_side_encryption': response.get('ServerSideEncryption')
                }
                logger.debug("Retrieved metadata for object asynchronously: %s", key)
                return metadata
        except Exception as e:
            logger.error("Failed to get metadata for object %s asynchronously: %s", key, e)
            return None
    
    async def upload_file_async(self, file_path: str, key: str, content_type: str = "application/octet-stream") -> bool:
        """Upload file asynchronously using multipart upload for large files"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.upload_file, file_path, key, content_type)
    
    async def download_file_async(self, key: str, file_path: str) -> bool:
        """Download object to file asynchronously"""
        try:
            data = await self.download_object_async(key)
            if data is None:
                return False
            
            file_path_obj = Path(file_path)
            file_path_obj.parent.mkdir(parents=True, exist_ok=True)
            
            # Use aiofiles for async file writing
            import aiofiles
            async with aiofiles.open(file_path_obj, 'wb') as f:
                await f.write(data)
            
            logger.debug("Downloaded object %s to %s asynchronously", key, file_path)
            return True
            
        except Exception as e:
            logger.error("Failed to download object %s to %s asynchronously: %s", key, file_path, e)
            return False
    
    async def list_objects_async(self, prefix: str = "", max_keys: int = 1000) -> List[str]:
        """List objects in S3 asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.list_objects, prefix, max_keys)
    
    async def list_objects_with_metadata_async(self, prefix: str = "", max_keys: int = 1000) -> List[Dict[str, Any]]:
        """List objects with metadata asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.list_objects_with_metadata, prefix, max_keys)
    
    async def copy_object_async(self, source_key: str, destination_key: str) -> bool:
        """Copy object within bucket asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.copy_object, source_key, destination_key)
    
    async def copy_object_to_s3_async(self, destination_config: 'S3Config', source_key: str, 
                                     destination_key: str, metadata: Optional[Dict[str, str]] = None,
                                     copy_metadata: bool = True) -> bool:
        """Copy object from this S3 instance to another S3 destination asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, 
            self.copy_object_to_s3, 
            destination_config, 
            source_key, 
            destination_key, 
            metadata, 
            copy_metadata
        )
    
    async def delete_objects_async(self, keys: List[str]) -> Dict[str, Any]:
        """Delete multiple objects asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.delete_objects, keys)
    
    async def generate_presigned_url_async(self, key: str, operation: str = "get_object", 
                                         expiration: int = 3600) -> Optional[str]:
        """Generate presigned URL for object asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.generate_presigned_url, key, operation, expiration)
    
    async def get_bucket_info_async(self) -> Dict[str, Any]:
        """Get bucket information asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_bucket_info)
    
    # Async Tagging Operations
    async def put_object_tags_async(self, key: str, tags: Dict[str, str]) -> bool:
        """Add or update object tags asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.put_object_tags, key, tags)
    
    async def get_object_tags_async(self, key: str) -> Optional[Dict[str, str]]:
        """Get object tags asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_object_tags, key)
    
    async def delete_object_tags_async(self, key: str) -> bool:
        """Delete all object tags asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.delete_object_tags, key)
    
    async def update_object_tags_async(self, key: str, tags: Dict[str, str], replace_all: bool = True) -> bool:
        """Update object tags asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.update_object_tags, key, tags, replace_all)
    
    async def list_objects_by_tag_async(self, tag_key: str, tag_value: Optional[str] = None, prefix: str = "") -> List[str]:
        """List objects by tag asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.list_objects_by_tag, tag_key, tag_value, prefix)
    
    async def list_objects_by_tags_async(self, tag_filters: Dict[str, str], prefix: str = "") -> List[str]:
        """List objects by multiple tags asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.list_objects_by_tags, tag_filters, prefix)
    
    async def get_tag_statistics_async(self, prefix: str = "") -> Dict[str, Any]:
        """Get tag statistics asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_tag_statistics, prefix)
    
    # Async Context Manager
    async def __aenter__(self):
        """Async context manager entry"""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        # Cleanup if needed
        pass
