"""
Trino Client for VastDBManager

This module provides Trino connection management and basic client functionality.
"""

import logging
from typing import Dict, Any
from contextlib import contextmanager

# Try to import trino, but make it optional
try:
    import trino
    TRINO_AVAILABLE = True
except ImportError:
    TRINO_AVAILABLE = False
    trino = None

logger = logging.getLogger(__name__)


class TrinoClient:
    """
    Trino client for executing queries against VAST data.
    
    This client manages Trino connections and provides a clean interface
    for executing SQL queries against VAST data via the Trino connector.
    """
    
    def __init__(self, host: str, port: int = 8080, user: str = "admin", 
                 catalog: str = "hive", schema: str = "default", 
                 source: str = "vastdbmanager", **kwargs):
        """
        Initialize Trino client.
        
        Args:
            host: Trino coordinator host
            port: Trino coordinator port
            user: Username for Trino connection
            catalog: Trino catalog name
            schema: Trino schema name
            source: Source identifier for Trino queries
            **kwargs: Additional connection parameters
        """
        if not TRINO_AVAILABLE:
            raise ImportError("Trino client not available. Install with: pip install trino")
        
        self.host = host
        self.port = port
        self.user = user
        self.catalog = catalog
        self.schema = schema
        self.source = source
        self.connection_params = kwargs
        
        # Connection will be created lazily
        self._connection = None
        
        logger.info(f"Initialized Trino client: {host}:{port}/{catalog}.{schema}")
    
    def get_connection(self):
        """Get or create Trino connection."""
        if self._connection is None:
            self._connection = trino.dbapi.connect(
                host=self.host,
                port=self.port,
                user=self.user,
                catalog=self.catalog,
                schema=self.schema,
                source=self.source,
                **self.connection_params
            )
        return self._connection
    
    @contextmanager
    def get_cursor(self):
        """Get a cursor context manager for executing queries."""
        connection = self.get_connection()
        cursor = connection.cursor()
        try:
            yield cursor
        finally:
            cursor.close()
    
    def execute_sql(self, sql: str) -> Dict[str, Any]:
        """
        Execute SQL query and return results.
        
        Args:
            sql: SQL query to execute
            
        Returns:
            Dictionary with query results and metadata
        """
        try:
            with self.get_cursor() as cursor:
                logger.debug(f"Executing Trino SQL: {sql}")
                cursor.execute(sql)
                
                # Get column names
                column_names = [desc[0] for desc in cursor.description] if cursor.description else []
                
                # Fetch all rows
                rows = cursor.fetchall()
                
                # Convert to dictionary format
                if rows and column_names:
                    data = {}
                    for i, col_name in enumerate(column_names):
                        data[col_name] = [row[i] for row in rows]
                else:
                    data = {}
                
                return {
                    'data': data,
                    'columns': column_names,
                    'row_count': len(rows) if rows else 0,
                    'affected_rows': cursor.rowcount if hasattr(cursor, 'rowcount') else 0
                }
                
        except Exception as e:
            logger.error(f"Error executing Trino SQL: {e}")
            raise
    
    def test_connection(self) -> bool:
        """
        Test the Trino connection.
        
        Returns:
            True if connection is successful, False otherwise
        """
        try:
            with self.get_cursor() as cursor:
                cursor.execute("SELECT 1")
                result = cursor.fetchone()
                return result is not None and result[0] == 1
        except Exception as e:
            logger.error(f"Trino connection test failed: {e}")
            return False
    
    def close(self):
        """Close Trino connection."""
        if self._connection:
            self._connection.close()
            self._connection = None
            logger.debug("Closed Trino connection")
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
