"""
Query Builder for Trino VAST Queries

This module provides a fluent query builder interface for constructing
SQL queries against VAST data via Trino, supporting SELECT, UPDATE, and DELETE operations.
"""

import logging
from typing import Dict, Any
from .sql_executor import SqlExecutor

logger = logging.getLogger(__name__)


class QueryBuilder:
    """
    Fluent query builder for Trino VAST queries.
    
    This class provides a fluent interface for building SQL queries
    with method chaining, supporting SELECT, UPDATE, and DELETE operations.
    """
    
    def __init__(self, sql_executor: SqlExecutor, table: str):
        """
        Initialize query builder.
        
        Args:
            sql_executor: SQL executor instance
            table: Table name for the query
        """
        self.sql_executor = sql_executor
        self.table = table
        self._operation = "SELECT"  # Default operation
        self._select = "*"
        self._set_clauses = []  # For UPDATE
        self._where_conditions = []
        self._joins = []
        self._group_by = []
        self._having_conditions = []
        self._order_by = []
        self._limit = None
        
        logger.debug(f"Initialized QueryBuilder for table: {table}")
    
    # SELECT operations
    def select(self, *columns: str) -> 'QueryBuilder':
        """
        Set columns to select.
        
        Args:
            *columns: Column names to select
            
        Returns:
            QueryBuilder instance for method chaining
        """
        if columns:
            self._select = ", ".join(columns)
        else:
            self._select = "*"
        
        logger.debug(f"Set SELECT columns: {self._select}")
        return self
    
    def where(self, condition: str) -> 'QueryBuilder':
        """
        Add WHERE condition.
        
        Args:
            condition: WHERE condition string
            
        Returns:
            QueryBuilder instance for method chaining
        """
        self._where_conditions.append(condition)
        logger.debug(f"Added WHERE condition: {condition}")
        return self
    
    def join(self, table: str, on: str) -> 'QueryBuilder':
        """
        Add JOIN clause.
        
        Args:
            table: Table to join
            on: JOIN condition
            
        Returns:
            QueryBuilder instance for method chaining
        """
        self._joins.append(f"JOIN {table} ON {on}")
        logger.debug(f"Added JOIN: {table} ON {on}")
        return self
    
    def left_join(self, table: str, on: str) -> 'QueryBuilder':
        """
        Add LEFT JOIN clause.
        
        Args:
            table: Table to join
            on: JOIN condition
            
        Returns:
            QueryBuilder instance for method chaining
        """
        self._joins.append(f"LEFT JOIN {table} ON {on}")
        logger.debug(f"Added LEFT JOIN: {table} ON {on}")
        return self
    
    def right_join(self, table: str, on: str) -> 'QueryBuilder':
        """
        Add RIGHT JOIN clause.
        
        Args:
            table: Table to join
            on: JOIN condition
            
        Returns:
            QueryBuilder instance for method chaining
        """
        self._joins.append(f"RIGHT JOIN {table} ON {on}")
        logger.debug(f"Added RIGHT JOIN: {table} ON {on}")
        return self
    
    def group_by(self, *columns: str) -> 'QueryBuilder':
        """
        Add GROUP BY clause.
        
        Args:
            *columns: Columns to group by
            
        Returns:
            QueryBuilder instance for method chaining
        """
        self._group_by.extend(columns)
        logger.debug(f"Added GROUP BY: {', '.join(columns)}")
        return self
    
    def having(self, condition: str) -> 'QueryBuilder':
        """
        Add HAVING condition.
        
        Args:
            condition: HAVING condition string
            
        Returns:
            QueryBuilder instance for method chaining
        """
        self._having_conditions.append(condition)
        logger.debug(f"Added HAVING condition: {condition}")
        return self
    
    def order_by(self, clause: str) -> 'QueryBuilder':
        """
        Add ORDER BY clause.
        
        Args:
            clause: ORDER BY clause string
            
        Returns:
            QueryBuilder instance for method chaining
        """
        self._order_by.append(clause)
        logger.debug(f"Added ORDER BY: {clause}")
        return self
    
    def limit(self, count: int) -> 'QueryBuilder':
        """
        Add LIMIT clause.
        
        Args:
            count: Number of rows to limit
            
        Returns:
            QueryBuilder instance for method chaining
        """
        self._limit = count
        logger.debug(f"Set LIMIT: {count}")
        return self
    
    # UPDATE operations
    def update(self) -> 'QueryBuilder':
        """
        Set operation to UPDATE.
        
        Returns:
            QueryBuilder instance for method chaining
        """
        self._operation = "UPDATE"
        logger.debug("Set operation to UPDATE")
        return self
    
    def set(self, **kwargs: Any) -> 'QueryBuilder':
        """
        Set column values for UPDATE.
        
        Args:
            **kwargs: Column=value pairs to set
            
        Returns:
            QueryBuilder instance for method chaining
        """
        for column, value in kwargs.items():
            formatted_value = self._format_value(value)
            self._set_clauses.append(f"{column} = {formatted_value}")
        
        logger.debug(f"Set UPDATE values: {self._set_clauses}")
        return self
    
    # DELETE operations
    def delete(self) -> 'QueryBuilder':
        """
        Set operation to DELETE.
        
        Returns:
            QueryBuilder instance for method chaining
        """
        self._operation = "DELETE"
        logger.debug("Set operation to DELETE")
        return self
    
    # Execution
    def execute(self) -> Dict[str, Any]:
        """
        Execute the built query.
        
        Returns:
            Query results
        """
        try:
            if self._operation == "SELECT":
                return self._execute_select()
            elif self._operation == "UPDATE":
                return self._execute_update()
            elif self._operation == "DELETE":
                return self._execute_delete()
            else:
                raise ValueError(f"Unknown operation: {self._operation}")
        except Exception as e:
            logger.error(f"Error executing query: {e}")
            raise
    
    def _execute_select(self) -> Dict[str, Any]:
        """Execute SELECT query."""
        sql = self._build_select_sql()
        return self.sql_executor.execute(sql)
    
    def _execute_update(self) -> Dict[str, Any]:
        """Execute UPDATE query."""
        if not self._set_clauses:
            raise ValueError("No SET clauses specified for UPDATE")
        if not self._where_conditions:
            raise ValueError("WHERE clause required for UPDATE")
        
        sql = self._build_update_sql()
        return self.sql_executor.execute(sql)
    
    def _execute_delete(self) -> Dict[str, Any]:
        """Execute DELETE query."""
        if not self._where_conditions:
            raise ValueError("WHERE clause required for DELETE")
        
        sql = self._build_delete_sql()
        return self.sql_executor.execute(sql)
    
    def _build_select_sql(self) -> str:
        """Build SELECT SQL from query builder state."""
        parts = [f"SELECT {self._select}"]
        parts.append(f"FROM {self.table}")
        
        if self._joins:
            parts.extend(self._joins)
        
        if self._where_conditions:
            where_clause = " AND ".join(self._where_conditions)
            parts.append(f"WHERE {where_clause}")
        
        if self._group_by:
            parts.append(f"GROUP BY {', '.join(self._group_by)}")
        
        if self._having_conditions:
            having_clause = " AND ".join(self._having_conditions)
            parts.append(f"HAVING {having_clause}")
        
        if self._order_by:
            parts.append(f"ORDER BY {', '.join(self._order_by)}")
        
        if self._limit:
            parts.append(f"LIMIT {self._limit}")
        
        sql = " ".join(parts)
        logger.debug(f"Built SELECT SQL: {sql}")
        return sql
    
    def _build_update_sql(self) -> str:
        """Build UPDATE SQL from query builder state."""
        parts = [f"UPDATE {self.table}"]
        parts.append(f"SET {', '.join(self._set_clauses)}")
        
        if self._where_conditions:
            where_clause = " AND ".join(self._where_conditions)
            parts.append(f"WHERE {where_clause}")
        
        sql = " ".join(parts)
        logger.debug(f"Built UPDATE SQL: {sql}")
        return sql
    
    def _build_delete_sql(self) -> str:
        """Build DELETE SQL from query builder state."""
        parts = [f"DELETE FROM {self.table}"]
        
        if self._where_conditions:
            where_clause = " AND ".join(self._where_conditions)
            parts.append(f"WHERE {where_clause}")
        
        sql = " ".join(parts)
        logger.debug(f"Built DELETE SQL: {sql}")
        return sql
    
    def _format_value(self, value: Any) -> str:
        """
        Format a value for use in SQL queries.
        
        Args:
            value: Value to format
            
        Returns:
            Formatted value string
        """
        if value is None:
            return 'NULL'
        elif isinstance(value, bool):
            return 'true' if value else 'false'
        elif isinstance(value, str):
            # Check if this is a SQL expression (like CAST(...) or TIMESTAMP '...')
            if value.upper().startswith(('CAST(', 'TIMESTAMP ', 'DATE ', 'TIME ')):
                # Don't wrap SQL expressions in quotes
                return value
            else:
                # Escape single quotes for regular string values
                escaped = value.replace("'", "''")
                return f"'{escaped}'"
        elif isinstance(value, (int, float)):
            return str(value)
        else:
            # Convert to string and escape
            escaped = str(value).replace("'", "''")
            return f"'{escaped}'"
    
    def to_sql(self) -> str:
        """
        Get the SQL string that would be executed.
        
        Returns:
            SQL string
        """
        if self._operation == "SELECT":
            return self._build_select_sql()
        elif self._operation == "UPDATE":
            return self._build_update_sql()
        elif self._operation == "DELETE":
            return self._build_delete_sql()
        else:
            raise ValueError(f"Cannot generate SQL for operation: {self._operation}")
