"""
S3 Object Tagging

This module provides comprehensive object tagging functionality including
CRUD operations and tag-based object searching.
"""

import logging
from typing import Dict, List, Optional, Any

# S3Client will be passed as parameter

logger = logging.getLogger(__name__)


class S3ObjectTagger:
    """
    Handles all S3 object tagging operations
    
    This class provides functionality for:
    - Adding and updating object tags
    - Retrieving object tags
    - Deleting object tags
    - Searching objects by tags
    """
    
    def __init__(self, s3_client):
        """
        Initialize object tagger
        
        Args:
            s3_client: S3Client instance for basic operations
        """
        self.s3_client = s3_client
        logger.debug("S3ObjectTagger initialized")
    
    def put_object_tags(self, key: str, tags: Dict[str, str], bucket: Optional[str] = None) -> bool:
        """
        Add or update tags for an S3 object
        
        Args:
            key: S3 object key
            tags: Dictionary of tag key-value pairs
            bucket: Bucket name. If None, uses bucket from config (if available)
            
        Returns:
            bool: True if successful, False otherwise
        """
        target_bucket = bucket or self.s3_client.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_key = self.s3_client._build_key(key)
            # Convert dict to S3 tag format
            tag_set = [{'Key': k, 'Value': v} for k, v in tags.items()]
            
            self.s3_client.s3_client.put_object_tagging(
                Bucket=target_bucket,
                Key=full_key,
                Tagging={'TagSet': tag_set}
            )
            
            logger.debug("Added tags to object %s: %s", key, tags)
            return True
            
        except Exception as e:
            logger.error("Failed to add tags to object %s: %s", key, e)
            return False
    
    def get_object_tags(self, key: str, bucket: Optional[str] = None) -> Optional[Dict[str, str]]:
        """
        Get tags for an S3 object
        
        Args:
            key: S3 object key
            bucket: Bucket name. If None, uses bucket from config (if available)
            
        Returns:
            Dict of tag key-value pairs, or None if failed
        """
        target_bucket = bucket or self.s3_client.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_key = self.s3_client._build_key(key)
            response = self.s3_client.s3_client.get_object_tagging(
                Bucket=target_bucket,
                Key=full_key
            )
            
            # Convert S3 tag format to dict
            tags = {}
            if 'TagSet' in response:
                for tag in response['TagSet']:
                    tags[tag['Key']] = tag['Value']
            
            logger.debug("Retrieved tags for object %s: %s", key, tags)
            return tags
            
        except Exception as e:
            logger.error("Failed to get tags for object %s: %s", key, e)
            return None
    
    def delete_object_tags(self, key: str, bucket: Optional[str] = None) -> bool:
        """
        Delete all tags from an S3 object
        
        Args:
            key: S3 object key
            bucket: Bucket name. If None, uses bucket from config (if available)
            
        Returns:
            bool: True if successful, False otherwise
        """
        target_bucket = bucket or self.s3_client.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_key = self.s3_client._build_key(key)
            self.s3_client.s3_client.delete_object_tagging(
                Bucket=target_bucket,
                Key=full_key
            )
            
            logger.debug("Deleted tags from object %s", key)
            return True
            
        except Exception as e:
            logger.error("Failed to delete tags from object %s: %s", key, e)
            return False
    
    def update_object_tags(self, key: str, tags: Dict[str, str], replace_all: bool = True, bucket: Optional[str] = None) -> bool:
        """
        Update tags for an S3 object
        
        Args:
            key: S3 object key
            tags: Dictionary of tag key-value pairs to add/update
            replace_all: If True, replace all existing tags. If False, merge with existing tags
            bucket: Bucket name. If None, uses bucket from config (if available)
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            if replace_all:
                # Replace all tags
                return self.put_object_tags(key, tags, bucket=bucket)
            else:
                # Merge with existing tags
                existing_tags = self.get_object_tags(key, bucket=bucket)
                if existing_tags is None:
                    # If we can't get existing tags, just add new ones
                    return self.put_object_tags(key, tags, bucket=bucket)
                
                # Merge existing tags with new tags (new tags override existing ones)
                merged_tags = {**existing_tags, **tags}
                return self.put_object_tags(key, merged_tags, bucket=bucket)
                
        except Exception as e:
            logger.error("Failed to update tags for object %s: %s", key, e)
            return False
    
    def list_objects_by_tag(self, tag_key: str, tag_value: Optional[str] = None, prefix: str = "") -> List[str]:
        """
        List objects that have specific tags
        
        Args:
            tag_key: Tag key to search for
            tag_value: Optional tag value to match (if None, matches any value)
            prefix: Optional prefix to limit search
            
        Returns:
            List of object keys that match the tag criteria
        """
        try:
            # First get all objects with the prefix
            from .objects import S3ObjectManager
            object_manager = S3ObjectManager(self.s3_client)
            all_objects = object_manager.list_objects(prefix=prefix)
            matching_objects = []
            
            for obj_key in all_objects:
                # Get tags for each object
                tags = self.get_object_tags(obj_key)
                if tags and tag_key in tags:
                    if tag_value is None or tags[tag_key] == tag_value:
                        matching_objects.append(obj_key)
            
            logger.info("Found %d objects matching tag %s=%s", 
                       len(matching_objects), tag_key, tag_value or "any")
            return matching_objects
            
        except Exception as e:
            logger.error("Failed to list objects by tag %s=%s: %s", tag_key, tag_value, e)
            return []
    
    def list_objects_by_tags(self, tag_filters: Dict[str, str], prefix: str = "") -> List[str]:
        """
        List objects that match multiple tag criteria
        
        Args:
            tag_filters: Dictionary of tag key-value pairs to match
            prefix: Optional prefix to limit search
            
        Returns:
            List of object keys that match all tag criteria
        """
        try:
            if not tag_filters:
                return []
            
            # First get all objects with the prefix
            from .objects import S3ObjectManager
            object_manager = S3ObjectManager(self.s3_client)
            all_objects = object_manager.list_objects(prefix=prefix)
            matching_objects = []
            
            for obj_key in all_objects:
                # Get tags for each object
                tags = self.get_object_tags(obj_key)
                if tags:
                    # Check if all tag filters match
                    matches = True
                    for tag_key, tag_value in tag_filters.items():
                        if tag_key not in tags or tags[tag_key] != tag_value:
                            matches = False
                            break
                    
                    if matches:
                        matching_objects.append(obj_key)
            
            logger.info("Found %d objects matching tag filters", 
                       len(matching_objects))
            return matching_objects
            
        except Exception as e:
            logger.error("Failed to list objects by tags %s: %s", tag_filters, e)
            return []
    
    def get_tag_statistics(self, prefix: str = "") -> Dict[str, Any]:
        """
        Get statistics about tags in the bucket
        
        Args:
            prefix: Optional prefix to limit search
            
        Returns:
            Dict containing tag statistics
        """
        try:
            from .objects import S3ObjectManager
            object_manager = S3ObjectManager(self.s3_client)
            all_objects = object_manager.list_objects(prefix=prefix)
            
            tag_counts = {}
            total_objects = len(all_objects)
            tagged_objects = 0
            
            for obj_key in all_objects:
                tags = self.get_object_tags(obj_key)
                if tags:
                    tagged_objects += 1
                    for tag_key, tag_value in tags.items():
                        if tag_key not in tag_counts:
                            tag_counts[tag_key] = {}
                        if tag_value not in tag_counts[tag_key]:
                            tag_counts[tag_key][tag_value] = 0
                        tag_counts[tag_key][tag_value] += 1
            
            statistics = {
                'total_objects': total_objects,
                'tagged_objects': tagged_objects,
                'untagged_objects': total_objects - tagged_objects,
                'tag_coverage': (tagged_objects / total_objects * 100) if total_objects > 0 else 0,
                'tag_counts': tag_counts,
                'unique_tag_keys': len(tag_counts)
            }
            
            logger.info("Generated tag statistics for %d objects", total_objects)
            return statistics
            
        except Exception as e:
            logger.error("Failed to get tag statistics: %s", e)
            return {
                'total_objects': 0,
                'tagged_objects': 0,
                'untagged_objects': 0,
                'tag_coverage': 0,
                'tag_counts': {},
                'unique_tag_keys': 0,
                'error': str(e)
            }
