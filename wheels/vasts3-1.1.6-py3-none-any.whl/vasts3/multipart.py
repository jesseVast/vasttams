"""
S3 Multipart Upload Handler

This module provides efficient multipart upload functionality for large files
and data, handling both in-memory and file-based uploads.
"""

import logging
import os
from concurrent.futures import ThreadPoolExecutor
from typing import Optional

# S3Client will be passed as parameter

logger = logging.getLogger(__name__)


class S3MultipartUploader:
    """
    Handles multipart uploads for large files and data
    
    This class provides efficient multipart upload functionality including:
    - In-memory multipart uploads
    - File-based multipart uploads
    - Automatic chunk size management
    - Concurrent part uploads
    """
    
    # Configuration Constants
    DEFAULT_CHUNK_SIZE = 8 * 1024 * 1024  # 8MB
    DEFAULT_MAX_CONCURRENT_PARTS = 10
    DEFAULT_MULTIPART_THRESHOLD = 64 * 1024 * 1024  # 64MB
    
    def __init__(self, s3_client, chunk_size: Optional[int] = None, max_concurrent_parts: Optional[int] = None):
        """
        Initialize multipart uploader
        
        Args:
            s3_client: S3Client instance for basic operations
            chunk_size: Size of each part in bytes
            max_concurrent_parts: Maximum number of concurrent part uploads
        """
        self.s3_client = s3_client
        self.chunk_size = chunk_size or self.DEFAULT_CHUNK_SIZE
        self.max_concurrent_parts = max_concurrent_parts or self.DEFAULT_MAX_CONCURRENT_PARTS
        
        logger.debug("S3MultipartUploader initialized - Chunk size: %d, Max concurrent: %d", 
                   self.chunk_size, self.max_concurrent_parts)
    
    def upload_object(self, key: str, data: bytes, content_type: str = "application/octet-stream") -> bool:
        """
        Upload data using multipart upload for large files
        
        Args:
            key: S3 object key
            data: Data to upload
            content_type: MIME type of the data
            
        Returns:
            bool: True if upload successful, False otherwise
        """
        try:
            full_key = self.s3_client._build_key(key)
            logger.debug("Starting multipart upload: %s (full key: %s, %d bytes)", key, full_key, len(data))
            
            # Initialize multipart upload
            response = self.s3_client.s3_client.create_multipart_upload(
                Bucket=self.s3_client.bucket_name,
                Key=full_key,
                ContentType=content_type
            )
            upload_id = response['UploadId']
            
            try:
                # Upload parts
                parts = []
                part_number = 1
                
                for i in range(0, len(data), self.chunk_size):
                    chunk = data[i:i + self.chunk_size]
                    
                    response = self.s3_client.s3_client.upload_part(
                        Bucket=self.s3_client.bucket_name,
                        Key=full_key,
                        PartNumber=part_number,
                        UploadId=upload_id,
                        Body=chunk
                    )
                    
                    parts.append({
                        'ETag': response['ETag'],
                        'PartNumber': part_number
                    })
                    
                    logger.debug("Uploaded part %d/%d for %s", part_number, 
                               (len(data) + self.chunk_size - 1) // self.chunk_size, key)
                    part_number += 1
                
                # Complete multipart upload
                self.s3_client.s3_client.complete_multipart_upload(
                    Bucket=self.s3_client.bucket_name,
                    Key=full_key,
                    UploadId=upload_id,
                    MultipartUpload={'Parts': parts}
                )
                
                logger.info("Completed multipart upload: %s (%d bytes)", key, len(data))
                return True
                
            except Exception as e:
                # Abort multipart upload on error
                logger.error("Error during multipart upload, aborting: %s", e)
                try:
                    self.s3_client.s3_client.abort_multipart_upload(
                        Bucket=self.s3_client.bucket_name,
                        Key=full_key,
                        UploadId=upload_id
                    )
                except Exception as abort_error:
                    logger.error("Failed to abort multipart upload: %s", abort_error)
                return False
                
        except Exception as e:
            logger.error("Failed to start multipart upload for %s: %s", key, e)
            return False
    
    def upload_file(self, file_path: str, key: str, content_type: str = "application/octet-stream") -> bool:
        """
        Upload a file using multipart upload for large files
        
        Args:
            file_path: Path to the file to upload
            key: S3 object key
            content_type: MIME type of the file
            
        Returns:
            bool: True if upload successful, False otherwise
        """
        try:
            if not os.path.exists(file_path):
                logger.error("File not found: %s", file_path)
                return False
            
            file_size = os.path.getsize(file_path)
            full_key = self.s3_client._build_key(key)
            
            logger.debug("Starting file multipart upload: %s -> %s (%d bytes)", file_path, full_key, file_size)
            
            # Initialize multipart upload
            response = self.s3_client.s3_client.create_multipart_upload(
                Bucket=self.s3_client.bucket_name,
                Key=full_key,
                ContentType=content_type
            )
            upload_id = response['UploadId']
            
            try:
                # Upload parts concurrently
                parts = []
                part_number = 1
                
                with ThreadPoolExecutor(max_workers=self.max_concurrent_parts) as executor:
                    futures = []
                    
                    with open(file_path, 'rb') as f:
                        while True:
                            chunk = f.read(self.chunk_size)
                            if not chunk:
                                break
                            
                            future = executor.submit(
                                self._upload_part,
                                full_key, upload_id, part_number, chunk
                            )
                            futures.append((future, part_number))
                            part_number += 1
                    
                    # Collect results
                    for future, part_num in futures:
                        try:
                            etag = future.result()
                            parts.append({
                                'ETag': etag,
                                'PartNumber': part_num
                            })
                            logger.debug("Uploaded part %d for %s", part_num, key)
                        except Exception as e:
                            logger.error("Failed to upload part %d for %s: %s", part_num, key, e)
                            raise
                
                # Sort parts by part number
                parts.sort(key=lambda x: x['PartNumber'])
                
                # Complete multipart upload
                self.s3_client.s3_client.complete_multipart_upload(
                    Bucket=self.s3_client.bucket_name,
                    Key=full_key,
                    UploadId=upload_id,
                    MultipartUpload={'Parts': parts}
                )
                
                logger.info("Completed file multipart upload: %s -> %s (%d bytes)", 
                           file_path, full_key, file_size)
                return True
                
            except Exception as e:
                # Abort multipart upload on error
                logger.error("Error during file multipart upload, aborting: %s", e)
                try:
                    self.s3_client.s3_client.abort_multipart_upload(
                        Bucket=self.s3_client.bucket_name,
                        Key=full_key,
                        UploadId=upload_id
                    )
                except Exception as abort_error:
                    logger.error("Failed to abort multipart upload: %s", abort_error)
                return False
                
        except Exception as e:
            logger.error("Failed to upload file %s to %s: %s", file_path, key, e)
            return False
    
    def _upload_part(self, key: str, upload_id: str, part_number: int, chunk: bytes) -> str:
        """
        Upload a single part of a multipart upload
        
        Args:
            key: S3 object key
            upload_id: Multipart upload ID
            part_number: Part number
            chunk: Data chunk to upload
            
        Returns:
            str: ETag of the uploaded part
        """
        response = self.s3_client.s3_client.upload_part(
            Bucket=self.s3_client.bucket_name,
            Key=key,
            PartNumber=part_number,
            UploadId=upload_id,
            Body=chunk
        )
        return response['ETag']
