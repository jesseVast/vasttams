"""
VASTDB Object Database Configuration

This module provides VASTDB-specific configuration that can be used independently
by any application that needs object database capabilities.
"""

import os
import toml
from pathlib import Path
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field, field_validator
from pydantic import ConfigDict


class TrinoConfig(BaseModel):
    """Trino query engine configuration."""
    # Allow field names that shadow BaseModel attributes (e.g., "schema")
    model_config = ConfigDict(protected_namespaces=())
    
    host: str = Field(default="docker", description="Trino coordinator host")
    port: int = Field(default=8080, description="Trino coordinator port")
    user: str = Field(default="admin", description="Username for Trino connection")
    catalog: str = Field(default="vast", description="Trino catalog name")
    schema_name: str = Field(default="default", alias="schema", description="Trino schema name")
    source: str = Field(default="vastdbmanager", description="Source identifier for Trino queries")

    @property
    def schema(self) -> str:  # backward-compatible attribute without pydantic warning
        return self.schema_name
    
    @schema.setter
    def schema(self, value: str) -> None:
        self.schema_name = value
    
    @field_validator('port')
    @classmethod
    def validate_port(cls, v):
        """Validate port number."""
        if not 1 <= v <= 65535:
            raise ValueError('Port must be between 1 and 65535')
        return v


class VASTDBConfig(BaseModel):
    """VASTDB object database configuration."""
    # Allow field names that shadow BaseModel attributes (e.g., "schema")
    model_config = ConfigDict(protected_namespaces=())
    
    endpoints: List[str] = Field(default=["localhost:42000"], description="VASTDB endpoints")
    access_key: str = Field(default="vastagents", description="Access key")
    secret_key: str = Field(default="vastagents", description="Secret key")
    bucket: str = Field(default="vastagents", description="Bucket name")
    schema_name: str = Field(default="vastagents", alias="schema", description="Schema name")
    timeout: int = Field(default=30, description="Request timeout in seconds")
    batch_size: int = Field(default=100, description="Batch size for operations")
    max_workers: int = Field(default=4, description="Maximum worker processes")
    max_retries: int = Field(default=3, description="Maximum retry attempts")
    
    # Trino configuration
    enable_trino: bool = Field(default=True, description="Enable Trino query capabilities (required)")
    trino: Optional[TrinoConfig] = Field(default=None, description="Trino configuration")
    
    @field_validator('endpoints')
    @classmethod
    def validate_endpoints(cls, v):
        """Validate endpoints list is not empty."""
        if not v:
            raise ValueError('Endpoints cannot be empty')
        return [endpoint.strip() for endpoint in v if endpoint.strip()]
    
    @field_validator('bucket', 'schema_name')
    @classmethod
    def validate_names(cls, v):
        """Validate bucket and schema names."""
        if not v or not v.strip():
            raise ValueError('Name cannot be empty')
        return v.strip()

    @property
    def schema(self) -> str:  # backward-compatible attribute without pydantic warning
        return self.schema_name
    
    @schema.setter
    def schema(self, value: str) -> None:
        self.schema_name = value
    
    @field_validator('batch_size', 'max_workers', 'max_retries')
    @classmethod
    def validate_positive_int(cls, v):
        """Validate positive integer values."""
        if v <= 0:
            raise ValueError('Value must be positive')
        return v
    
    @classmethod
    def from_toml(cls, config_path: str) -> 'VASTDBConfig':
        """Load configuration from TOML file.
        
        Args:
            config_path: Path to TOML configuration file
            
        Returns:
            VASTDBConfig instance loaded from file
            
        Raises:
            FileNotFoundError: If config file doesn't exist
            ValueError: If config file is invalid
        """
        config_file = Path(config_path)
        if not config_file.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        
        try:
            with open(config_file, 'r') as f:
                config_data = toml.load(f)
            
            # Extract vastdb section or use root level
            vastdb_data = config_data.get('vastdb', config_data)
            
            # Handle Trino configuration
            if 'trino' in vastdb_data:
                trino_data = vastdb_data.pop('trino')
                vastdb_data['trino'] = TrinoConfig(**trino_data)
            
            return cls(**vastdb_data)
            
        except toml.TomlDecodeError as e:
            raise ValueError(f"Invalid TOML configuration file: {e}")
        except Exception as e:
            raise ValueError(f"Error loading configuration: {e}")
    
    @classmethod
    def from_env(cls) -> 'VASTDBConfig':
        """Load configuration from environment variables.
        
        Environment variables should be prefixed with 'VASTDB_'.
        For example: VASTDB_ENDPOINTS, VASTDB_ACCESS_KEY, etc.
        
        Returns:
            VASTDBConfig instance loaded from environment
        """
        env_data = {}
        
        # Map environment variables to config fields
        env_mapping = {
            'VASTDB_ENDPOINTS': 'endpoints',
            'VASTDB_ACCESS_KEY': 'access_key',
            'VASTDB_SECRET_KEY': 'secret_key',
            'VASTDB_BUCKET': 'bucket',
            'VASTDB_SCHEMA': 'schema',
            'VASTDB_TIMEOUT': 'timeout',
            'VASTDB_BATCH_SIZE': 'batch_size',
            'VASTDB_MAX_WORKERS': 'max_workers',
            'VASTDB_MAX_RETRIES': 'max_retries',
            'VASTDB_ENABLE_TRINO': 'enable_trino'
        }
        
        for env_var, config_field in env_mapping.items():
            value = os.getenv(env_var)
            if value is not None:
                if config_field == 'endpoints':
                    env_data[config_field] = [s.strip() for s in value.split(',')]
                elif config_field in ['timeout', 'batch_size', 'max_workers', 'max_retries']:
                    env_data[config_field] = int(value)
                elif config_field == 'enable_trino':
                    env_data[config_field] = value.lower() in ['true', '1', 'yes', 'on']
                else:
                    env_data[config_field] = value
        
        # Handle Trino environment variables
        trino_config = {}
        trino_env_mapping = {
            'TRINO_HOST': 'host',
            'TRINO_PORT': 'port',
            'TRINO_USER': 'user',
            'TRINO_CATALOG': 'catalog',
            'TRINO_SCHEMA': 'schema',
            'TRINO_SOURCE': 'source'
        }
        
        for env_var, config_field in trino_env_mapping.items():
            value = os.getenv(env_var)
            if value is not None:
                if config_field == 'port':
                    trino_config[config_field] = int(value)
                else:
                    trino_config[config_field] = value
        
        if trino_config:
            env_data['trino'] = TrinoConfig(**trino_config)
        
        return cls(**env_data)
    
    def to_toml(self, config_path: str) -> None:
        """Save configuration to TOML file.
        
        Args:
            config_path: Path where to save the TOML configuration file
        """
        config_file = Path(config_path)
        config_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Write configuration to TOML file
        config_data = {'vastdb': self.model_dump(by_alias=True)}
        with open(config_file, 'w') as f:
            toml.dump(config_data, f)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary.
        
        Returns:
            Dictionary representation of the configuration
        """
        return self.model_dump()
