"""Connection management for VastDBManager"""

import logging
import asyncio
import vastdb
from typing import List, Union, Optional

logger = logging.getLogger(__name__)

# Configuration constants
VAST_TIMEOUT = 30  # VAST connection timeout in seconds


class ConnectionManager:
    """Manages VAST database connections and endpoints"""
    
    def __init__(self, endpoints: Union[str, List[str]], access_key: str, secret_key: str, 
                 bucket: str, schema: str, timeout: int = VAST_TIMEOUT):
        """
        Initialize connection manager
        
        Args:
            endpoints: Single endpoint string or list of endpoints
            access_key: VASTDB access key for authentication
            secret_key: VASTDB secret key for authentication
            bucket: VASTDB bucket name
            schema: VASTDB schema name
            timeout: Connection timeout in seconds (default: VAST_TIMEOUT)
        """
        # Convert single endpoint to list for consistency
        if isinstance(endpoints, str):
            self.endpoints = [endpoints]
        else:
            self.endpoints = endpoints
        
        self.access_key = access_key
        self.secret_key = secret_key
        self.bucket = bucket
        self.schema = schema
        self.timeout = timeout
        
        self.connection = None
        
        logger.info(f"Initialized ConnectionManager with {len(self.endpoints)} endpoints")
    
    def connect(self):
        """Connect to VAST database using the first available endpoint"""
        try:
            # Use first endpoint for connection
            endpoint = self.endpoints[0]
            self.connection = vastdb.connect(
                endpoint=endpoint,
                access=self.access_key,
                secret=self.secret_key,
                timeout=self.timeout
            )
            
            # Setup schema
            self._setup_schema()
            logger.info(f"Connected to VAST database at {endpoint}")
            
        except Exception as e:
            logger.error(f"Failed to connect to VAST database: {e}")
            raise
    
    def _setup_schema(self):
        """Setup database schema and discover existing tables"""
        try:
            with self.connection.transaction() as tx:
                bucket = tx.bucket(self.bucket)
                
                # Ensure schema exists
                schema = bucket.schema(self.schema, fail_if_missing=False)
                if schema is None:
                    schema = bucket.create_schema(self.schema)
                    logger.info(f"Schema '{self.schema}' created")
                else:
                    logger.info(f"Schema '{self.schema}' already exists")
                
        except Exception as e:
            logger.error(f"Failed to setup schema: {e}")
            raise
    
    def connect_to_endpoint(self, endpoint: Optional[str] = None):
        """Connect to a specific VAST database endpoint"""
        try:
            if endpoint is None:
                endpoint = self.endpoints[0]  # Use first endpoint as fallback
            
            self.connection = vastdb.connect(
                endpoint=endpoint,
                access=self.access_key,
                secret=self.secret_key,
                timeout=self.timeout
            )
            
            logger.info(f"Connected to VAST database at {endpoint}")
            
        except Exception as e:
            logger.error(f"Failed to connect to VAST database: {e}")
            raise
    
    def disconnect(self):
        """Disconnect from VAST database"""
        if self.connection:
            # VAST connection object (Session) doesn't have a close() method
            # Just set to None to indicate disconnection
            self.connection = None
            logger.info("Disconnected from VAST database")
    
    def is_connected(self) -> bool:
        """Check if connected to VAST database"""
        return self.connection is not None
    
    def get_connection(self):
        """Get the current VAST connection"""
        return self.connection
    
    def get_bucket(self) -> str:
        """Get the current bucket name"""
        return self.bucket
    
    def get_schema(self) -> str:
        """Get the current schema name"""
        return self.schema
    
    # Async Methods
    async def connect_async(self):
        """Connect to VAST database asynchronously using the first available endpoint"""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.connect)
    
    async def connect_to_endpoint_async(self, endpoint: Optional[str] = None):
        """Connect to a specific VAST database endpoint asynchronously"""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.connect_to_endpoint, endpoint)
    
    async def disconnect_async(self):
        """Disconnect from VAST database asynchronously"""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.disconnect)
    
    async def _setup_schema_async(self):
        """Setup database schema and discover existing tables asynchronously"""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._setup_schema)
