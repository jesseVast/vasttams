"""
SQL Executor for Trino VAST Queries

This module provides raw SQL execution capabilities for Trino queries
against VAST data, with proper error handling and result formatting.
"""

import logging
import re
import time
from typing import Dict, Any, Optional
from .client import TrinoClient
from .schema_mapper import SchemaMapper

logger = logging.getLogger(__name__)


class SqlExecutor:
    """
    Executes raw SQL queries against VAST data via Trino.
    
    This class provides a clean interface for executing SQL queries
    with proper error handling, result formatting, and performance monitoring.
    """
    
    def __init__(self, trino_client: TrinoClient, schema_mapper: SchemaMapper):
        """
        Initialize SQL executor.
        
        Args:
            trino_client: Trino client instance
            schema_mapper: Schema mapper instance
        """
        self.trino_client = trino_client
        self.schema_mapper = schema_mapper
        logger.debug("Initialized SqlExecutor")
    
    def execute(self, sql: str) -> Dict[str, Any]:
        """
        Execute a raw SQL query.
        
        Args:
            sql: SQL query to execute
            
        Returns:
            Dictionary with query results and metadata
        """
        try:
            start_time = time.time()
            
            # Validate SQL query
            self._validate_sql(sql)
            
            # Execute query
            result = self.trino_client.execute_sql(sql)
            
            execution_time = time.time() - start_time
            
            # Add execution metadata
            result['execution_time'] = execution_time
            result['sql'] = sql
            
            logger.debug(f"SQL executed successfully in {execution_time:.3f}s")
            return result
            
        except Exception as e:
            logger.error(f"Error executing SQL: {e}")
            raise
    
    def execute_select(self, table: str, columns: str = "*", 
                      where: Optional[str] = None, 
                      order_by: Optional[str] = None,
                      limit: Optional[int] = None) -> Dict[str, Any]:
        """
        Execute a SELECT query with common parameters.
        
        Args:
            table: Table name (can be qualified or simple)
            columns: Columns to select
            where: WHERE clause
            order_by: ORDER BY clause
            limit: LIMIT clause
            
        Returns:
            Query results
        """
        sql_parts = [f"SELECT {columns}"]
        sql_parts.append(f"FROM {table}")
        
        if where:
            sql_parts.append(f"WHERE {where}")
        
        if order_by:
            sql_parts.append(f"ORDER BY {order_by}")
        
        if limit:
            sql_parts.append(f"LIMIT {limit}")
        
        sql = " ".join(sql_parts)
        return self.execute(sql)
    
    def execute_update(self, table: str, set_clauses: Dict[str, Any], 
                      where: str) -> Dict[str, Any]:
        """
        Execute an UPDATE query.
        
        Args:
            table: Table name
            set_clauses: Dictionary of column=value pairs
            where: WHERE clause
            
        Returns:
            Update results with affected rows
        """
        if not set_clauses:
            raise ValueError("No SET clauses provided for UPDATE")
        
        set_parts = []
        for column, value in set_clauses.items():
            formatted_value = self._format_value(value)
            set_parts.append(f"{column} = {formatted_value}")
        
        sql = f"UPDATE {table} SET {', '.join(set_parts)} WHERE {where}"
        return self.execute(sql)
    
    def execute_delete(self, table: str, where: str) -> Dict[str, Any]:
        """
        Execute a DELETE query.
        
        Args:
            table: Table name
            where: WHERE clause
            
        Returns:
            Delete results with affected rows
        """
        sql = f"DELETE FROM {table} WHERE {where}"
        return self.execute(sql)
    
    def execute_with_qualified_table(self, sql: str, bucket: str, schema: str) -> Dict[str, Any]:
        """
        Execute SQL with automatic table qualification.
        
        This method replaces simple table names in SQL with fully qualified
        VAST table names using the schema mapper.
        
        Args:
            sql: SQL query with simple table names
            bucket: VAST bucket name
            schema: VAST schema name
            
        Returns:
            Query results
        """
        # This is a simplified implementation
        # In practice, you might want to parse the SQL and replace table names
        # For now, we'll assume the SQL already has qualified table names
        return self.execute(sql)
    
    def _validate_sql(self, sql: str) -> None:
        """
        Validate SQL query for safety.
        
        Args:
            sql: SQL query to validate
            
        Raises:
            ValueError: If SQL query is invalid or unsafe
        """
        if not sql or not isinstance(sql, str):
            raise ValueError("SQL query cannot be empty")
        
        sql_upper = sql.upper().strip()
        
        # Check for dangerous operations using word boundaries
        # This ensures we match SQL keywords, not substrings in identifiers
        dangerous_operations = ['DROP', 'TRUNCATE', 'ALTER', 'CREATE', 'GRANT', 'REVOKE']
        for operation in dangerous_operations:
            # Use word boundary regex to match whole words only
            # \b ensures we match "CREATE TABLE" but not "created_at"
            pattern = r'\b' + re.escape(operation) + r'\b'
            if re.search(pattern, sql_upper):
                raise ValueError(f"Dangerous operation '{operation}' not allowed")
        
        # Check for basic SQL structure
        if not any(sql_upper.startswith(op) for op in ['SELECT', 'UPDATE', 'DELETE', 'INSERT']):
            raise ValueError("SQL query must start with SELECT, UPDATE, DELETE, or INSERT")
        
        logger.debug("SQL validation passed")
    
    def _format_value(self, value: Any) -> str:
        """
        Format a value for use in SQL queries.
        
        Args:
            value: Value to format
            
        Returns:
            Formatted value string
        """
        if value is None:
            return 'NULL'
        elif isinstance(value, bool):
            return 'true' if value else 'false'
        elif isinstance(value, str):
            # Escape single quotes
            escaped = value.replace("'", "''")
            return f"'{escaped}'"
        elif isinstance(value, (int, float)):
            return str(value)
        else:
            # Convert to string and escape
            escaped = str(value).replace("'", "''")
            return f"'{escaped}'"
    
    def get_table_info(self, table: str) -> Dict[str, Any]:
        """
        Get information about a table.
        
        Args:
            table: Table name
            
        Returns:
            Table information
        """
        # This would query Trino's information_schema
        # For now, return a placeholder
        return {
            'table_name': table,
            'columns': [],
            'row_count': 0
        }
