"""
VAST database management operations for VastAgents.

This module provides VAST database management operations including connection
management, table operations, data operations, and analytics capabilities.

Modules:
    core: Core database operations
    data_operations: Data manipulation operations
    table_operations: Table management operations
    cache: Caching operations
    trino: Trino-based query operations
"""

__version__ = "1.1.8"
__all__ = [
    "VastDBManager",
    "core",
    "data_operations",
    "table_operations", 
    "cache"
]

# Import main modules to make them available at package level
from . import core
from . import data_operations
from . import table_operations
from . import cache

# Import VastDBManager for easy access
from .core import VastDBManager
