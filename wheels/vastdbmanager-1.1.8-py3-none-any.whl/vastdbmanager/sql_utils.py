"""
Simple SQL utilities for VastDBManager

This module provides simple utilities for handling SQL table names
in Trino queries, making it easy for users to use simple table names
while ensuring correct Trino format.
"""

import re
import logging
from typing import List, Tuple

logger = logging.getLogger(__name__)


def extract_table_references(sql: str) -> List[Tuple[str, str, int, int]]:
    """
    Extract table references from SQL statement.
    
    Returns a list of tuples: (clause_type, table_name, start_pos, end_pos)
    where clause_type is one of: 'FROM', 'JOIN', 'LEFT_JOIN', 'RIGHT_JOIN', 'UPDATE', 'DELETE_FROM'
    """
    if not sql or not isinstance(sql, str):
        return []
    
    references = []
    
    # Define patterns for different SQL clauses
    # Use negative lookbehind to avoid overlaps
    patterns = [
        (r'\bDELETE\s+FROM\s+([^\s,]+)', 'DELETE_FROM'),
        (r'\bLEFT\s+JOIN\s+([^\s,]+)', 'LEFT_JOIN'),
        (r'\bRIGHT\s+JOIN\s+([^\s,]+)', 'RIGHT_JOIN'),
        (r'(?<!LEFT\s)(?<!RIGHT\s)\bJOIN\s+([^\s,]+)', 'JOIN'),  # JOIN not preceded by LEFT or RIGHT
        (r'\bUPDATE\s+([^\s,]+)', 'UPDATE'),
        (r'(?<!DELETE\s)\bFROM\s+([^\s,]+)', 'FROM'),  # FROM not preceded by DELETE
    ]
    
    for pattern, clause_type in patterns:
        for match in re.finditer(pattern, sql, re.IGNORECASE):
            table_name = match.group(1)
            start_pos = match.start(1)
            end_pos = match.end(1)
            references.append((clause_type, table_name, start_pos, end_pos))
    
    return references


def is_valid_sql_identifier(name: str) -> bool:
    """
    Check if a string is a valid SQL identifier (simple table name).
    
    Valid identifiers:
    - Start with letter or underscore
    - Contain only letters, numbers, and underscores
    - Do not contain dots (which indicate qualification)
    """
    if not name or not isinstance(name, str):
        return False
    
    # Check if it contains dots (already qualified)
    if '.' in name:
        return False
    
    # Check if it starts with letter or underscore
    if not re.match(r'^[a-zA-Z_]', name):
        return False
    
    # Check if it contains only valid characters
    if not re.match(r'^[a-zA-Z0-9_]+$', name):
        return False
    
    return True


def format_sql_table_names(sql: str, bucket: str, schema: str) -> str:
    """
    Format table names in SQL to use Trino VAST format.
    
    This function finds simple table names in SQL statements and converts them
    to the proper Trino format: vast."bucket/schema".table
    
    Args:
        sql: SQL statement with simple table names
        bucket: VAST bucket name
        schema: VAST schema name
        
    Returns:
        SQL statement with properly formatted table names
    """
    if not sql or not isinstance(sql, str):
        return sql
    
    # Extract all table references
    references = extract_table_references(sql)
    
    # Process references in reverse order to avoid position shifts
    references.sort(key=lambda x: x[2], reverse=True)
    
    formatted_sql = sql
    changes_made = []
    
    for clause_type, table_name, start_pos, end_pos in references:
        # Only format valid SQL identifiers (simple table names)
        if is_valid_sql_identifier(table_name):
            qualified_name = f'vast."{bucket}/{schema}".{table_name}'
            formatted_sql = formatted_sql[:start_pos] + qualified_name + formatted_sql[end_pos:]
            changes_made.append(f"{table_name} -> {qualified_name}")
            logger.debug(f"Formatted table name: {table_name} -> {qualified_name}")
        else:
            logger.debug(f"Skipping invalid identifier: {table_name}")
    
    # Log the transformation if changes were made
    if changes_made and formatted_sql != sql:
        logger.debug(f"SQL table names formatted - Original: {sql}")
        logger.debug(f"SQL table names formatted - Modified: {formatted_sql}")
        logger.debug(f"SQL table names formatted - Changes: {', '.join(changes_made)}")
    
    return formatted_sql


def extract_table_names(sql: str) -> List[str]:
    """
    Extract table names from SQL statement.
    
    Args:
        sql: SQL statement
        
    Returns:
        List of table names found in the SQL
    """
    if not sql or not isinstance(sql, str):
        return []
    
    references = extract_table_references(sql)
    table_names = [ref[1] for ref in references]
    
    # Remove duplicates while preserving order
    seen = set()
    unique_tables = []
    for table in table_names:
        if table not in seen:
            seen.add(table)
            unique_tables.append(table)
    
    return unique_tables


def is_simple_table_name(table_name: str) -> bool:
    """
    Check if a table name is simple (not qualified with dots).
    
    Args:
        table_name: Table name to check
        
    Returns:
        True if table name is simple (no dots), False otherwise
    """
    if not table_name or not isinstance(table_name, str):
        return False
    
    # Check if it's just whitespace
    if not table_name.strip():
        return False
    
    return '.' not in table_name.strip()


def validate_sql_table_names(sql: str, bucket: str, schema: str) -> bool:
    """
    Validate that SQL contains simple table names that can be formatted.
    
    Args:
        sql: SQL statement to validate
        bucket: VAST bucket name
        schema: VAST schema name
        
    Returns:
        True if all table names are simple and can be formatted
    """
    table_names = extract_table_names(sql)
    
    for table_name in table_names:
        if not is_simple_table_name(table_name):
            logger.warning(f"SQL validation failed - Table name '{table_name}' is already qualified and will not be formatted")
            logger.info(f"SQL validation failed - Original SQL: {sql}")
            logger.info(f"SQL validation failed - Invalid table names: {[t for t in table_names if not is_simple_table_name(t)]}")
            return False
    
    return True