"""
Schema Mapper for Trino VAST Queries

This module handles the mapping between VAST bucket/schema names and
Trino catalog/schema references for the VAST connector.
"""

import logging
from typing import Tuple

logger = logging.getLogger(__name__)


class SchemaMapper:
    """
    Maps VAST bucket/schema names to Trino catalog/schema references.
    
    The VAST connector in Trino uses the format: vast."bucket/schema"
    This class provides utilities for working with this format.
    """
    
    def __init__(self, vast_catalog: str = "vast"):
        """
        Initialize schema mapper.
        
        Args:
            vast_catalog: The Trino catalog name for VAST connector
        """
        self.vast_catalog = vast_catalog
        logger.debug(f"Initialized SchemaMapper with catalog: {vast_catalog}")
    
    def get_qualified_table_name(self, bucket: str, schema: str, table: str) -> str:
        """
        Get fully qualified table name for Trino VAST queries.
        
        Args:
            bucket: VAST bucket name
            schema: VAST schema name
            table: Table name
            
        Returns:
            Fully qualified table name in format: vast."bucket/schema".table
        """
        qualified_name = f'{self.vast_catalog}."{bucket}/{schema}".{table}'
        logger.debug(f"Generated qualified table name: {qualified_name}")
        return qualified_name
    
    def parse_qualified_name(self, qualified_name: str) -> Tuple[str, str, str]:
        """
        Parse a qualified table name into its components.
        
        Args:
            qualified_name: Fully qualified table name
            
        Returns:
            Tuple of (catalog, schema, table)
        """
        try:
            # Expected format: vast."bucket/schema".table
            parts = qualified_name.split('.')
            if len(parts) != 3:
                raise ValueError(f"Invalid qualified name format: {qualified_name}")
            
            catalog = parts[0]
            schema_with_quotes = parts[1]
            table = parts[2]
            
            # Remove quotes from schema
            if schema_with_quotes.startswith('"') and schema_with_quotes.endswith('"'):
                schema = schema_with_quotes[1:-1]
            else:
                schema = schema_with_quotes
            
            # Split bucket/schema
            if '/' in schema:
                bucket, schema = schema.split('/', 1)
            else:
                bucket = schema
                schema = "default"
            
            logger.debug(f"Parsed qualified name: catalog={catalog}, bucket={bucket}, schema={schema}, table={table}")
            return catalog, bucket, schema, table
            
        except Exception as e:
            logger.error(f"Error parsing qualified name '{qualified_name}': {e}")
            raise ValueError(f"Invalid qualified name format: {qualified_name}")
    
    def get_schema_reference(self, bucket: str, schema: str) -> str:
        """
        Get schema reference for Trino VAST queries.
        
        Args:
            bucket: VAST bucket name
            schema: VAST schema name
            
        Returns:
            Schema reference in format: vast."bucket/schema"
        """
        schema_ref = f'{self.vast_catalog}."{bucket}/{schema}"'
        logger.debug(f"Generated schema reference: {schema_ref}")
        return schema_ref
    
    def validate_table_name(self, table_name: str) -> bool:
        """
        Validate that a table name is safe for SQL queries.
        
        Args:
            table_name: Table name to validate
            
        Returns:
            True if valid, False otherwise
        """
        if not table_name or not isinstance(table_name, str):
            return False
        
        # Check for SQL injection patterns
        # Only check for actual SQL injection patterns, not SQL Server-specific or substring matches
        dangerous_patterns = [';', '--', '/*', '*/']
        table_lower = table_name.lower()
        
        for pattern in dangerous_patterns:
            if pattern in table_lower:
                logger.warning(f"Potentially dangerous pattern in table name: {pattern}")
                return False
        
        # Check for valid identifier characters
        if not table_name.replace('_', '').replace('-', '').isalnum():
            logger.warning(f"Table name contains invalid characters: {table_name}")
            return False
        
        return True
    
    def escape_identifier(self, identifier: str) -> str:
        """
        Escape an identifier for safe use in SQL queries.
        
        Args:
            identifier: Identifier to escape
            
        Returns:
            Escaped identifier
        """
        # For Trino, identifiers with special characters should be quoted
        if not identifier.replace('_', '').replace('-', '').isalnum():
            return f'"{identifier}"'
        return identifier
