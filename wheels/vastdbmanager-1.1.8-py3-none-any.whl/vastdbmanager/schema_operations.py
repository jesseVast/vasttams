"""Schema operations for VastDBManager

Based on VAST Data Platform schema management documentation:
https://vast-data.github.io/data-platform-field-docs/vast_database/sdk_ref/02_schema_management.html
"""

import logging
import asyncio
from typing import List, Optional

logger = logging.getLogger(__name__)


class SchemaOperations:
    """Handles schema creation, listing, retrieval, renaming, and deletion"""
    
    def __init__(self, connection_manager):
        """Initialize schema operations with connection manager"""
        self.connection_manager = connection_manager
    
    def create_schema(self, schema_name: str, fail_if_exists: bool = True) -> bool:
        """Create a new schema (a container of tables) in a bucket"""
        try:
            if not self.connection_manager.is_connected():
                raise RuntimeError("Not connected to VAST database")
            
            connection = self.connection_manager.get_connection()
            bucket = self.connection_manager.get_bucket()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                
                # Check if schema already exists
                existing_schema = bucket_obj.schema(schema_name, fail_if_missing=False)
                if existing_schema is not None:
                    if fail_if_exists:
                        raise RuntimeError(f"Schema {schema_name} already exists")
                    else:
                        logger.info(f"Schema {schema_name} already exists, skipping creation")
                        return True
                
                # Create new schema using VAST's actual API
                bucket_obj.create_schema(schema_name, fail_if_exists=fail_if_exists)
                logger.info(f"Created schema '{schema_name}' in bucket {bucket}")
                return True
                
        except Exception as e:
            logger.error(f"Failed to create schema {schema_name}: {e}")
            raise
    
    def list_schemas(self, batch_size: int = 1000) -> List[str]:
        """List all schemas in a bucket"""
        try:
            if not self.connection_manager.is_connected():
                raise RuntimeError("Not connected to VAST database")
            
            connection = self.connection_manager.get_connection()
            bucket = self.connection_manager.get_bucket()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                
                # Get all schemas using VAST's actual API
                schemas = bucket_obj.schemas(batch_size=batch_size)
                schema_names = [schema.name for schema in schemas]
                
                logger.debug(f"Retrieved {len(schema_names)} schemas from bucket {bucket}")
                return schema_names
                
        except Exception as e:
            logger.error(f"Failed to list schemas: {e}")
            raise
    
    def get_schema(self, schema_name: str, fail_if_missing: bool = True) -> Optional[object]:
        """Get a specific schema (a container of tables) under this bucket"""
        try:
            if not self.connection_manager.is_connected():
                raise RuntimeError("Not connected to VAST database")
            
            connection = self.connection_manager.get_connection()
            bucket = self.connection_manager.get_bucket()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                
                # Get schema using VAST's actual API
                schema = bucket_obj.schema(name=schema_name, fail_if_missing=fail_if_missing)
                
                if schema is None:
                    logger.warning(f"Schema {schema_name} not found")
                    return None
                
                logger.debug(f"Retrieved schema '{schema_name}' from bucket {bucket}")
                return schema
                
        except Exception as e:
            logger.error(f"Failed to get schema {schema_name}: {e}")
            if fail_if_missing:
                raise
            return None
    
    def rename_schema(self, current_schema_name: str, new_schema_name: str) -> bool:
        """Rename a schema"""
        try:
            if not self.connection_manager.is_connected():
                raise RuntimeError("Not connected to VAST database")
            
            connection = self.connection_manager.get_connection()
            bucket = self.connection_manager.get_bucket()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                schema = bucket_obj.schema(name=current_schema_name, fail_if_missing=False)
                
                if schema is None:
                    raise RuntimeError(f"Schema {current_schema_name} not found")
                
                # Rename schema using VAST's actual API
                schema.rename(new_name=new_schema_name)
                logger.info(f"Renamed schema '{current_schema_name}' to '{new_schema_name}'")
                return True
                
        except Exception as e:
            logger.error(f"Failed to rename schema {current_schema_name}: {e}")
            raise
    
    def drop_schema(self, schema_name: str) -> bool:
        """Delete a schema in a bucket
        
        Note: Schema can only be dropped if it has no tables
        """
        try:
            if not self.connection_manager.is_connected():
                raise RuntimeError("Not connected to VAST database")
            
            connection = self.connection_manager.get_connection()
            bucket = self.connection_manager.get_bucket()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                schema = bucket_obj.schema(name=schema_name, fail_if_missing=False)
                
                if schema is None:
                    logger.warning(f"Schema {schema_name} not found, nothing to drop")
                    return False
                
                # Check if schema has tables
                tables = schema.tables()
                if tables:
                    table_names = [table.name for table in tables]
                    raise RuntimeError(f"Cannot drop schema {schema_name} because it contains tables: {table_names}")
                
                # Drop schema using VAST's actual API
                schema.drop()
                logger.info(f"Dropped schema '{schema_name}' from bucket {bucket}")
                return True
                
        except Exception as e:
            logger.error(f"Failed to drop schema {schema_name}: {e}")
            raise
    
    def schema_exists(self, schema_name: str) -> bool:
        """Check if a schema exists in the bucket"""
        try:
            schema = self.get_schema(schema_name, fail_if_missing=False)
            return schema is not None
        except Exception as e:
            logger.error(f"Failed to check if schema exists {schema_name}: {e}")
            return False
    
    def get_schema_tables(self, schema_name: str) -> List[str]:
        """Get list of table names in a schema"""
        try:
            if not self.connection_manager.is_connected():
                raise RuntimeError("Not connected to VAST database")
            
            connection = self.connection_manager.get_connection()
            bucket = self.connection_manager.get_bucket()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                schema = bucket_obj.schema(name=schema_name, fail_if_missing=False)
                
                if schema is None:
                    logger.warning(f"Schema {schema_name} not found")
                    return []
                
                # Get tables using VAST's actual API within the same transaction
                tables = schema.tables()
                table_names = [table.name for table in tables]
                logger.debug(f"Retrieved {len(table_names)} tables from schema {schema_name}")
                return table_names
            
        except Exception as e:
            logger.error(f"Failed to get tables for schema {schema_name}: {e}")
            raise
    
    # Async Methods
    async def create_schema_async(self, schema_name: str, fail_if_exists: bool = True) -> bool:
        """Create a new schema asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.create_schema, schema_name, fail_if_exists)
    
    async def list_schemas_async(self, batch_size: int = 1000) -> List[str]:
        """List all schemas in a bucket asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.list_schemas, batch_size)
    
    async def get_schema_async(self, schema_name: str, fail_if_missing: bool = True) -> Optional[object]:
        """Get a specific schema asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_schema, schema_name, fail_if_missing)
    
    async def rename_schema_async(self, current_schema_name: str, new_schema_name: str) -> bool:
        """Rename a schema asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.rename_schema, current_schema_name, new_schema_name)
    
    async def drop_schema_async(self, schema_name: str) -> bool:
        """Delete a schema in a bucket asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.drop_schema, schema_name)
    
    async def schema_exists_async(self, schema_name: str) -> bool:
        """Check if a schema exists in the bucket asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.schema_exists, schema_name)
    
    async def get_schema_tables_async(self, schema_name: str) -> List[str]:
        """Get list of table names in a schema asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_schema_tables, schema_name)
