"""
S3 Storage Configuration

This module provides S3-specific configuration that can be used independently
by any application that needs S3 storage capabilities.
"""

import os
import toml
from pathlib import Path
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field, field_validator
from pydantic import ConfigDict


class S3Config(BaseModel):
    """S3 storage configuration."""
    # Pydantic v2 configuration
    model_config = ConfigDict(extra='forbid', validate_assignment=True, populate_by_name=True)
    
    endpoint_url: str = Field(default="http://your-s3-endpoint:9000", description="S3 endpoint URL")
    bucket_name: Optional[str] = Field(default=None, description="S3 bucket name (optional)")
    region: str = Field(default="us-east-1", description="AWS region")
    access_key: Optional[str] = Field(default=None, description="Access key")
    secret_key: Optional[str] = Field(default=None, description="Secret key")
    key_prefix: str = Field(default="", description="Key prefix for all S3 operations")
    use_ssl: bool = Field(default=False, description="Use SSL for connections")
    verify_ssl: bool = Field(default=True, description="Verify SSL certificates")
    chunk_size: int = Field(default=8388608, description="Chunk size for multipart uploads (8MB)")
    max_concurrent_parts: int = Field(default=10, description="Maximum concurrent parts")
    timeout: int = Field(default=60, description="Request timeout in seconds")
    headers: Optional[Dict[str, str]] = Field(default=None, description="Optional headers to include in S3 requests")
    
    @field_validator('endpoint_url')
    @classmethod
    def validate_endpoint_url(cls, v):
        """Validate S3 endpoint URL."""
        if not v or not v.strip():
            raise ValueError('S3 endpoint URL cannot be empty')
        return v.strip()
    
    @field_validator('bucket_name')
    @classmethod
    def validate_bucket_name(cls, v):
        """Validate bucket name - can be None for bucketless operations."""
        if v is None:
            return v
        if not v.strip():
            raise ValueError('Bucket name cannot be empty if provided')
        return v.strip()
    
    @field_validator('region')
    @classmethod
    def validate_region(cls, v):
        """Validate region name."""
        if not v or not v.strip():
            raise ValueError('Region cannot be empty')
        return v.strip()
    
    @field_validator('chunk_size', 'max_concurrent_parts')
    @classmethod
    def validate_positive_int(cls, v):
        """Validate positive integer values."""
        if v <= 0:
            raise ValueError('Value must be positive')
        return v
    
    @field_validator('headers')
    @classmethod
    def validate_headers(cls, v):
        """Validate headers dictionary."""
        if v is None:
            return v
        if not isinstance(v, dict):
            raise ValueError('Headers must be a dictionary')
        for key, value in v.items():
            if not isinstance(key, str) or not isinstance(value, str):
                raise ValueError('Header keys and values must be strings')
        return v
    
    @classmethod
    def from_toml(cls, config_path: str) -> 'S3Config':
        """Load configuration from TOML file.
        
        Args:
            config_path: Path to TOML configuration file
            
        Returns:
            S3Config instance loaded from file
            
        Raises:
            FileNotFoundError: If config file doesn't exist
            ValueError: If config file is invalid
        """
        config_file = Path(config_path)
        if not config_file.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        
        try:
            with open(config_file, 'r') as f:
                config_data = toml.load(f)
            
            # Extract s3 section or use root level
            s3_data = config_data.get('s3', config_data)
            return cls(**s3_data)
            
        except toml.TomlDecodeError as e:
            raise ValueError(f"Invalid TOML configuration file: {e}")
        except Exception as e:
            raise ValueError(f"Error loading configuration: {e}")
    
    @classmethod
    def from_env(cls) -> 'S3Config':
        """Load configuration from environment variables.
        
        Environment variables should be prefixed with 'S3_'.
        For example: S3_ENDPOINT_URL, S3_BUCKET_NAME, etc.
        
        Returns:
            S3Config instance loaded from environment
        """
        env_data = {}
        
        # Map environment variables to config fields
        env_mapping = {
            'S3_ENDPOINT_URL': 'endpoint_url',
            'S3_BUCKET_NAME': 'bucket_name',
            'S3_REGION': 'region',
            'S3_ACCESS_KEY': 'access_key',
            'S3_SECRET_KEY': 'secret_key',
            'S3_KEY_PREFIX': 'key_prefix',
            'S3_USE_SSL': 'use_ssl',
            'S3_VERIFY_SSL': 'verify_ssl',
            'S3_CHUNK_SIZE': 'chunk_size',
            'S3_MAX_CONCURRENT_PARTS': 'max_concurrent_parts',
            'S3_TIMEOUT': 'timeout',
            'S3_HEADERS': 'headers'
        }
        
        for env_var, config_field in env_mapping.items():
            value = os.getenv(env_var)
            if value is not None:
                if config_field in ['use_ssl', 'verify_ssl']:
                    env_data[config_field] = value.lower() in ('true', '1', 'yes', 'on')
                elif config_field in ['chunk_size', 'max_concurrent_parts', 'timeout']:
                    env_data[config_field] = int(value)
                elif config_field == 'headers':
                    # Parse headers from JSON string or key=value pairs
                    try:
                        import json
                        env_data[config_field] = json.loads(value)
                    except (json.JSONDecodeError, ValueError):
                        # Fallback to key=value format
                        headers = {}
                        for pair in value.split(','):
                            if '=' in pair:
                                key, val = pair.split('=', 1)
                                headers[key.strip()] = val.strip()
                        env_data[config_field] = headers if headers else None
                else:
                    env_data[config_field] = value
        
        return cls(**env_data)
    
    def to_toml(self, config_path: str) -> None:
        """Save configuration to TOML file.
        
        Args:
            config_path: Path where to save the TOML configuration file
        """
        config_file = Path(config_path)
        config_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Write configuration to TOML file
        config_data = {'s3': self.model_dump()}
        with open(config_file, 'w') as f:
            toml.dump(config_data, f)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary.
        
        Returns:
            Dictionary representation of the configuration
        """
        return self.model_dump()
