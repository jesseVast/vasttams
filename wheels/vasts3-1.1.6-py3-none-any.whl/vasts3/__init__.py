"""
S3 storage operations for VastAgents.

This module provides S3 storage operations including file upload, download,
presigned URL generation, and bucket management operations.

Classes:
    S3Client: Main S3 client interface
    VastS3Client: Alias for S3Client (for consistency with other modules)
    S3MultipartUploader: Multipart upload handling
    S3ObjectManager: Object management and listing
    S3ObjectTagger: Object tagging operations
    S3Config: S3 configuration management
"""

__version__ = "1.1.1"
__all__ = [
    "S3Client",
    "VastS3Client",  # Alias for consistency with other modules
    "S3MultipartUploader",
    "S3ObjectManager",
    "S3ObjectTagger",
    "S3Config"
]

# Import main classes to make them available at module level
from .client import S3Client
from .multipart import S3MultipartUploader
from .objects import S3ObjectManager
from .tags import S3ObjectTagger
from .config import S3Config

# Create alias for consistency with other modules
VastS3Client = S3Client
