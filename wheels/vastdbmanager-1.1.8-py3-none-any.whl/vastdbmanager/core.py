"""Refactored Core VastDBManager integrating all modular components"""

import logging
import asyncio
from typing import List, Dict, Any, Optional, Union

try:
    from pyarrow import Schema
except ImportError:
    # Type stub for when pyarrow is not available during type checking
    class Schema:
        pass

from .cache import CacheManager
from .trino import TrinoClient, QueryBuilder, SqlExecutor, SchemaMapper
from .schema_operations import SchemaOperations
from .sql_utils import format_sql_table_names
from .connection_manager import ConnectionManager
from .table_operations import TableOperations
from .data_operations import DataOperations
from .batch_operations import BatchOperations

# Configuration constants
DEFAULT_BATCH_SIZE = 100
DEFAULT_MAX_WORKERS = 4
PARALLEL_THRESHOLD = 10
DEFAULT_MAX_RETRIES = 3

logger = logging.getLogger(__name__)


class VastDBManager:
    """Refactored VastDBManager with modular architecture"""
    
    def __init__(self, endpoints: Union[str, List[str]], access_key: str, secret_key: str, 
                 bucket: str, schema: str, auto_connect: bool = True, timeout: int = 30,
                 batch_size: int = DEFAULT_BATCH_SIZE, max_workers: int = DEFAULT_MAX_WORKERS,
                 max_retries: int = DEFAULT_MAX_RETRIES,
                 enable_trino: bool = True,
                 trino_host: str = "docker", trino_port: int = 8080, 
                 trino_user: str = "admin", trino_catalog: str = "vast"):
        """
        Initialize VastDBManager with modular components
        
        Args:
            endpoints: Single endpoint string or list of endpoints
            access_key: VASTDB access key for authentication
            secret_key: VASTDB secret key for authentication
            bucket: VASTDB bucket name
            schema: VASTDB schema name
            auto_connect: Whether to automatically connect to the database
            timeout: Connection timeout in seconds
            batch_size: Default batch size for operations
            max_workers: Maximum number of parallel workers
            max_retries: Maximum retry attempts for failed operations
            enable_trino: Whether to enable Trino query capabilities (default: True, required)
            trino_host: Trino coordinator host
            trino_port: Trino coordinator port
            trino_user: Trino username
            trino_catalog: Trino catalog name for VAST connector
        """
        # Store configuration
        self.access_key = access_key
        self.secret_key = secret_key
        self.bucket = bucket
        self.schema = schema
        self.timeout = timeout
        self.batch_size = batch_size
        self.max_workers = max_workers
        self.max_retries = max_retries
        
        # Initialize modular components
        self.connection_manager = ConnectionManager(
            endpoints, access_key, secret_key, bucket, schema, timeout
        )
        self.cache_manager = CacheManager()
        self.schema_operations = SchemaOperations(self.connection_manager)
        self.table_operations = TableOperations(self.connection_manager)
        self.data_operations = DataOperations(
            self.connection_manager, 
            self.cache_manager, 
            batch_size=self.batch_size,
            max_retries=self.max_retries
        )
        self.batch_operations = BatchOperations(
            self.data_operations, 
            batch_size=self.batch_size,
            max_workers=self.max_workers,
            max_retries=self.max_retries
        )
        
        # Initialize performance monitoring
        # (Analytics components removed - use Trino for complex analytics)
        
        # Initialize Trino components if enabled
        self.enable_trino = enable_trino
        self.trino_client = None
        self.sql_executor = None
        self.schema_mapper = None
        
        if enable_trino:
            try:
                self.schema_mapper = SchemaMapper(trino_catalog)
                self.trino_client = TrinoClient(
                    host=trino_host,
                    port=trino_port,
                    user=trino_user,
                    catalog=trino_catalog,
                    schema="default"  # Will be overridden per query
                )
                self.sql_executor = SqlExecutor(self.trino_client, self.schema_mapper)
                logger.info(f"Initialized Trino query system: {trino_host}:{trino_port}/{trino_catalog}")
            except Exception as e:
                logger.error(f"Failed to initialize Trino: {e}")
                self.enable_trino = False
        
        # Initialize connection to first endpoint if auto_connect is enabled
        if auto_connect:
            self.connection_manager.connect()
            
            # Discover existing tables
            self._discover_tables()
        
        logger.info(f"Initialized VastDBManager with {len(self.connection_manager.endpoints)} endpoints")
    
    def _discover_tables(self):
        """Discover and cache existing table schemas at startup"""
        try:
            if not self.connection_manager.is_connected():
                return
            
            connection = self.connection_manager.get_connection()
            if connection is None:
                logger.error("No connection available for table discovery")
                return
                
            bucket = self.connection_manager.get_bucket()
            schema_name = self.connection_manager.get_schema()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                schema_obj = bucket_obj.schema(schema_name)
                
                for table in schema_obj.tables():
                    table_name = table.name
                    # Cache only essential metadata: schema and initial row count
                    table_stats = table.get_stats()
                    total_rows = getattr(table_stats, 'total_rows', 0) or 0
                    self.cache_manager.update_table_cache(table_name, table.columns(), total_rows)
                    if logger.isEnabledFor(logging.DEBUG):
                        logger.debug("Discovered and cached table: %s (%s rows)", table_name, total_rows)
                    
            logger.info(f"Discovered and cached {len(self.cache_manager.get_all_table_names())} tables")
                    
        except Exception as e:
            logger.error(f"Failed to discover tables: {e}")
            raise
    
    @property
    def tables(self) -> List[str]:
        """Get list of available table names from cache"""
        try:
            return self.cache_manager.get_all_table_names()
        except Exception as e:
            logger.error(f"Error getting tables: {e}")
            return []
    
    def list_tables(self) -> List[str]:
        """Get list of available table names"""
        return self.tables
    
    def connect(self):
        """Connect to VAST database using the first available endpoint"""
        self.connection_manager.connect()
    
    def connect_to_endpoint(self, endpoint: Optional[str] = None):
        """Connect to a specific VAST database endpoint"""
        self.connection_manager.connect_to_endpoint(endpoint)
    
    def disconnect(self):
        """Disconnect from VAST database"""
        self.connection_manager.disconnect()
    
    
    def get_table_stats(self, table_name: str) -> Dict[str, Any]:
        """Get table statistics"""
        try:
            # Check cache first
            stats = self.cache_manager.get_table_stats(table_name)
            if stats.get('total_rows', 0) > 0:
                return stats
            
            # Fetch from database if not cached
            if self.connection_manager.is_connected():
                connection = self.connection_manager.get_connection()
                if connection is None:
                    logger.error("No connection available for table stats")
                    return {'total_rows': 0}
                    
                bucket = self.connection_manager.get_bucket()
                schema_name = self.connection_manager.get_schema()
                
                with connection.transaction() as tx:
                    bucket_obj = tx.bucket(bucket)
                    schema_obj = bucket_obj.schema(schema_name)
                    table = schema_obj.table(table_name)
                    vast_stats = table.get_stats()
                    
                    total_rows = getattr(vast_stats, 'total_rows', 0) or 0
                    columns = table.columns()
                    
                    # Update cache
                    self.cache_manager.update_table_cache(table_name, columns, total_rows)
                    
                    return {'total_rows': total_rows}
            
            return {'total_rows': 0}
            
        except Exception as e:
            logger.error(f"Error getting stats for table {table_name}: {e}")
            return {'total_rows': 0}
    
    def create_table(self, table_name: str, schema: Schema, projections: Optional[Dict[str, List[str]]] = None):
        """Create a new table with VAST projections for optimal performance, or evolve existing table schema"""
        return self.table_operations.create_table(table_name, schema, projections)
    
    def get_table_projections(self, table_name: str) -> List[str]:
        """Get list of projection names for a table"""
        return self.table_operations.get_table_projections(table_name)
    
    def add_projection(self, table_name: str, projection_name: str, columns: List[str]):
        """Add a new projection to an existing table"""
        return self.table_operations.add_projection(table_name, projection_name, columns)
    
    def drop_projection(self, table_name: str, projection_name: str):
        """Drop (delete) a projection from an existing table"""
        return self.table_operations.drop_projection(table_name, projection_name)
    
    def drop_table(self, table_name: str):
        """Drop (delete) a table from the schema"""
        return self.table_operations.drop_table(table_name)
    
    def drop_schema(self, schema_name: Optional[str] = None):
        """Drop (delete) a schema from the database
        
        Note: Schema can only be dropped if it has no tables
        """
        if schema_name is None:
            schema_name = self.connection_manager.get_schema()
        return self.schema_operations.drop_schema(schema_name)
    
    # Schema Management - Delegate to SchemaOperations module
    def create_schema(self, schema_name: str, fail_if_exists: bool = True) -> bool:
        """Create a new schema (a container of tables) in a bucket"""
        return self.schema_operations.create_schema(schema_name, fail_if_exists)
    
    def list_schemas(self, batch_size: int = 1000) -> List[str]:
        """List all schemas in a bucket"""
        return self.schema_operations.list_schemas(batch_size)
    
    def get_schema(self, schema_name: str, fail_if_missing: bool = True) -> Optional[object]:
        """Get a specific schema (a container of tables) under this bucket"""
        return self.schema_operations.get_schema(schema_name, fail_if_missing)
    
    def rename_schema(self, current_schema_name: str, new_schema_name: str) -> bool:
        """Rename a schema"""
        return self.schema_operations.rename_schema(current_schema_name, new_schema_name)
    
    def schema_exists(self, schema_name: str) -> bool:
        """Check if a schema exists in the bucket"""
        return self.schema_operations.schema_exists(schema_name)
    
    def get_schema_tables(self, schema_name: str) -> List[str]:
        """Get list of table names in a schema"""
        return self.schema_operations.get_schema_tables(schema_name)
    
    # Column Management - Delegate to TableOperations module
    def get_table_columns(self, table_name: str) -> Optional[Schema]:
        """Get all columns of a table"""
        return self.table_operations.get_table_columns(table_name)
    
    def add_columns(self, table_name: str, new_columns: Schema):
        """Add new columns to an existing table"""
        return self.table_operations.add_columns(table_name, new_columns)
    
    def rename_column(self, table_name: str, current_column_name: str, new_column_name: str):
        """Rename a column in a table"""
        return self.table_operations.rename_column(table_name, current_column_name, new_column_name)
    
    def drop_column(self, table_name: str, column_to_drop: Schema):
        """Remove columns from a table"""
        return self.table_operations.drop_column(table_name, column_to_drop)
    
    def column_exists(self, table_name: str, column_name: str) -> bool:
        """Check if a column exists in a table"""
        return self.table_operations.column_exists(table_name, column_name)
    
    # Data Operations - Delegate to DataOperations module
    def insert_single_record(self, table_name: str, data: Dict[str, Any]):
        """Insert a single Python dictionary record into a table"""
        return self.data_operations.insert_single_record(table_name, data)
    
    def insert_record_list(self, table_name: str, data: List[Dict[str, Any]]):
        """Insert a list of Python dictionary records into a table"""
        return self.data_operations.insert_record_list(table_name, data)
    
    def query_with_predicates(self, table_name: str, predicates: Optional[Any] = None, 
                             columns: Optional[List[str]] = None, limit: Optional[int] = None,
                             include_row_ids: bool = False):
        """Query data from a table with optional predicates using VAST's query capabilities"""
        return self.data_operations.query_with_predicates(
            table_name, predicates, columns, limit, include_row_ids
        )
    
    def update(self, table_name: str, data: Dict[str, List[Any]], predicate: Optional[Any] = None):
        """Update data in a table using VAST's native UPDATE capability"""
        return self.data_operations.update(table_name, data, predicate)
    
    def delete(self, table_name: str, predicate: Optional[Any] = None):
        """Delete data from a table using VAST's native DELETE capability"""
        return self.data_operations.delete(table_name, predicate)
    
    def insert(self, table_name: str, data: Dict[str, List[Any]]):
        """Insert data from a Python dictionary with row pooling and cache updates"""
        return self.data_operations.insert(table_name, data)
    
    def insert_record(self, table_name: str, data: Dict[str, Any]):
        """Insert a single record - compatibility method for storage endpoints"""
        try:
            self.data_operations.insert_single_record(table_name, data)
            return True
        except Exception as e:
            logger.error(f"Error inserting record into table {table_name}: {e}")
            return False
    
    def select(self, table_name: str, predicate: Optional[Any] = None, 
               output_by_row: bool = False, columns: Optional[List[str]] = None):
        """Query data from a table with optional predicates"""
        return self.data_operations.select(table_name, predicate, output_by_row, columns)
    
    # Batch Operations - Delegate to BatchOperations module
    def insert_batch_efficient(self, table_name: str, data: Dict[str, List[Any]], 
                              batch_size: int = DEFAULT_BATCH_SIZE, max_workers: int = DEFAULT_MAX_WORKERS):
        """Insert large datasets efficiently using row pooling and parallel processing"""
        return self.batch_operations.insert_batch_efficient(table_name, data, batch_size, max_workers)
    
    def insert_batch_transactional(self, table_name: str, data: Dict[str, List[Any]], 
                                  batch_size: int = DEFAULT_BATCH_SIZE, max_workers: int = DEFAULT_MAX_WORKERS, 
                                  max_retries: int = DEFAULT_MAX_RETRIES, enable_rollback: bool = True):
        """Insert data with transactional safety - no records are lost on failure"""
        return self.batch_operations.insert_batch_transactional(
            table_name, data, batch_size, max_workers, max_retries, enable_rollback
        )
    
    def cleanup_partial_insertion(self, table_name: str, failed_batch_ids: List[str], 
                                 batch_details: Dict[str, Any]) -> bool:
        """Clean up partial insertions when batch operations fail"""
        return self.batch_operations.cleanup_partial_insertion(table_name, failed_batch_ids, batch_details)
    
    # Analytics and Performance
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        return self.cache_manager.get_cache_stats()
    
    def clear_cache(self):
        """Clear all cached data"""
        self.cache_manager.clear_cache()
        logger.info("Cleared all cached data")
    
    def refresh_table_metadata(self, table_name: str):
        """Refresh table metadata in cache (useful when columns change)"""
        try:
            if not self.connection_manager.is_connected():
                logger.warning(f"Cannot refresh metadata for {table_name}: not connected")
                return
            
            connection = self.connection_manager.get_connection()
            if connection is None:
                logger.error(f"No connection available for metadata refresh of {table_name}")
                return
                
            bucket = self.connection_manager.get_bucket()
            schema_name = self.connection_manager.get_schema()
            
            with connection.transaction() as tx:
                bucket_obj = tx.bucket(bucket)
                schema_obj = bucket_obj.schema(schema_name)
                table = schema_obj.table(table_name)
                
                # Get fresh metadata
                table_stats = table.get_stats()
                total_rows = getattr(table_stats, 'total_rows', 0) or 0
                columns = table.columns()
                
                # Update cache with fresh metadata
                self.cache_manager.update_table_cache(table_name, columns, total_rows)
                logger.info(f"Refreshed metadata for table {table_name}: {total_rows} rows, {len(columns)} columns")
                
        except Exception as e:
            logger.error(f"Error refreshing metadata for table {table_name}: {e}")
            # Invalidate cache on error to force fresh fetch next time
            self.cache_manager.invalidate_table_cache(table_name)
    
    # Trino Query Methods
    def execute_sql(self, sql: str) -> Dict[str, Any]:
        """
        Execute raw SQL query using Trino.
        
        This method automatically formats simple table names in SQL statements
        to use the correct Trino VAST format (vast."bucket/schema".table).
        
        Args:
            sql: SQL query to execute (can use simple table names)
            
        Returns:
            Query results dictionary
            
        Raises:
            RuntimeError: If Trino is not enabled
        """
        if not self.enable_trino or not self.sql_executor:
            raise RuntimeError("Trino query system is not enabled. Set enable_trino=True in constructor.")
        
        # Automatically format table names for Trino using class bucket/schema
        formatted_sql = self._format_sql_for_trino(sql)
        
        # Log if SQL was modified
        if formatted_sql != sql:
            logger.debug(f"Formatted SQL for Trino: {sql} -> {formatted_sql}")
        
        return self.sql_executor.execute(formatted_sql)
    
    def _format_sql_for_trino(self, sql: str) -> str:
        """
        Format SQL table names for Trino using the instance's bucket and schema.
        
        This is a convenience method that uses the VastDBManager's bucket and schema
        without requiring them to be passed as parameters.
        
        Args:
            sql: SQL statement with simple table names
            
        Returns:
            SQL statement with properly formatted table names
        """
        return format_sql_table_names(sql, self.bucket, self.schema)
    
    def format_sql(self, sql: str) -> str:
        """
        Format SQL table names for Trino using the instance's bucket and schema.
        
        This method formats simple table names in SQL statements to use the correct
        Trino VAST format without executing the query. Useful for previewing how
        SQL will be formatted before execution.
        
        Args:
            sql: SQL statement with simple table names
            
        Returns:
            SQL statement with properly formatted table names
            
        Example:
            >>> vastdb = VastDBManager(...)
            >>> sql = "SELECT * FROM users WHERE id = 1"
            >>> formatted = vastdb.format_sql(sql)
            >>> print(formatted)
            SELECT * FROM vast."bucket/schema".users WHERE id = 1
        """
        return self._format_sql_for_trino(sql)
    
    def query(self, table: str) -> QueryBuilder:
        """
        Start a query builder for the specified table.
        
        Args:
            table: Table name (will be qualified with bucket/schema)
            
        Returns:
            QueryBuilder instance for method chaining
            
        Raises:
            RuntimeError: If Trino is not enabled
        """
        if not self.enable_trino or not self.sql_executor or not self.schema_mapper:
            raise RuntimeError("Trino query system is not enabled. Set enable_trino=True in constructor.")
        
        # Qualify table name with bucket/schema
        qualified_table = self.schema_mapper.get_qualified_table_name(
            self.bucket, self.schema, table
        )
        
        return QueryBuilder(self.sql_executor, qualified_table)
    
    def get_qualified_table_name(self, table: str) -> str:
        """
        Get fully qualified table name for Trino queries.
        
        Args:
            table: Simple table name
            
        Returns:
            Fully qualified table name in format: vast."bucket/schema".table
        """
        if not self.enable_trino or not self.schema_mapper:
            raise RuntimeError("Trino query system is not enabled. Set enable_trino=True in constructor.")
        
        return self.schema_mapper.get_qualified_table_name(self.bucket, self.schema, table)
    
    def test_trino_connection(self) -> bool:
        """
        Test the Trino connection.
        
        Returns:
            True if connection is successful, False otherwise
        """
        if not self.enable_trino or not self.trino_client:
            return False
        
        return self.trino_client.test_connection()
    
    def close(self):
        """Cleanup resources"""
        try:
            # Close connections
            self.disconnect()
            
            # Close Trino connection if enabled
            if self.enable_trino and self.trino_client:
                self.trino_client.close()
            
            logger.info("VastDBManager closed successfully")
            
        except Exception as e:
            logger.error(f"Error closing VastDBManager: {e}")
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close()
    
    # Async Methods
    async def connect_async(self):
        """Connect to VAST database asynchronously using the first available endpoint"""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.connection_manager.connect)
    
    async def connect_to_endpoint_async(self, endpoint: Optional[str] = None):
        """Connect to a specific VAST database endpoint asynchronously"""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.connection_manager.connect_to_endpoint, endpoint)
    
    async def disconnect_async(self):
        """Disconnect from VAST database asynchronously"""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.connection_manager.disconnect)
    
    
    async def get_table_stats_async(self, table_name: str) -> Dict[str, Any]:
        """Get table statistics asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_table_stats, table_name)
    
    async def create_table_async(self, table_name: str, schema: Schema, projections: Optional[Dict[str, List[str]]] = None):
        """Create a new table with VAST projections asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.create_table, table_name, schema, projections)
    
    async def get_table_projections_async(self, table_name: str) -> List[str]:
        """Get list of projection names for a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_table_projections, table_name)
    
    async def add_projection_async(self, table_name: str, projection_name: str, columns: List[str]):
        """Add a new projection to an existing table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.add_projection, table_name, projection_name, columns)
    
    async def drop_projection_async(self, table_name: str, projection_name: str):
        """Drop (delete) a projection from an existing table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.drop_projection, table_name, projection_name)
    
    async def drop_table_async(self, table_name: str):
        """Drop (delete) a table from the schema asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.drop_table, table_name)
    
    async def drop_schema_async(self, schema_name: Optional[str] = None):
        """Drop (delete) a schema from the database asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.drop_schema, schema_name)
    
    # Async Schema Management
    async def create_schema_async(self, schema_name: str, fail_if_exists: bool = True) -> bool:
        """Create a new schema asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.create_schema, schema_name, fail_if_exists)
    
    async def list_schemas_async(self, batch_size: int = 1000) -> List[str]:
        """List all schemas in a bucket asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.list_schemas, batch_size)
    
    async def get_schema_async(self, schema_name: str, fail_if_missing: bool = True) -> Optional[object]:
        """Get a specific schema asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_schema, schema_name, fail_if_missing)
    
    async def rename_schema_async(self, current_schema_name: str, new_schema_name: str) -> bool:
        """Rename a schema asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.rename_schema, current_schema_name, new_schema_name)
    
    async def schema_exists_async(self, schema_name: str) -> bool:
        """Check if a schema exists in the bucket asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.schema_exists, schema_name)
    
    async def get_schema_tables_async(self, schema_name: str) -> List[str]:
        """Get list of table names in a schema asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_schema_tables, schema_name)
    
    # Async Column Management
    async def get_table_columns_async(self, table_name: str) -> Optional[Schema]:
        """Get all columns of a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_table_columns, table_name)
    
    async def add_columns_async(self, table_name: str, new_columns: Schema):
        """Add new columns to an existing table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.add_columns, table_name, new_columns)
    
    async def rename_column_async(self, table_name: str, current_column_name: str, new_column_name: str):
        """Rename a column in a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.rename_column, table_name, current_column_name, new_column_name)
    
    async def drop_column_async(self, table_name: str, column_to_drop: Schema):
        """Remove columns from a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.drop_column, table_name, column_to_drop)
    
    async def column_exists_async(self, table_name: str, column_name: str) -> bool:
        """Check if a column exists in a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.column_exists, table_name, column_name)
    
    # Async Data Operations
    async def insert_single_record_async(self, table_name: str, data: Dict[str, Any]):
        """Insert a single Python dictionary record into a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.insert_single_record, table_name, data)
    
    async def insert_record_list_async(self, table_name: str, data: List[Dict[str, Any]]):
        """Insert a list of Python dictionary records into a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.insert_record_list, table_name, data)
    
    async def query_with_predicates_async(self, table_name: str, predicates: Optional[Any] = None, 
                                        columns: Optional[List[str]] = None, limit: Optional[int] = None,
                                        include_row_ids: bool = False):
        """Query data from a table with optional predicates asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.query_with_predicates, 
                                        table_name, predicates, columns, limit, include_row_ids)
    
    async def update_async(self, table_name: str, data: Dict[str, List[Any]], predicate: Optional[Any] = None):
        """Update data in a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.update, table_name, data, predicate)
    
    async def delete_async(self, table_name: str, predicate: Optional[Any] = None):
        """Delete data from a table asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.delete, table_name, predicate)
    
    async def insert_async(self, table_name: str, data: Dict[str, List[Any]]):
        """Insert data from a Python dictionary asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.insert, table_name, data)
    
    async def insert_record_async(self, table_name: str, data: Dict[str, Any]):
        """Insert a single record asynchronously - compatibility method for storage endpoints"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.insert_record, table_name, data)
    
    async def select_async(self, table_name: str, predicate: Optional[Any] = None, 
                          output_by_row: bool = False, columns: Optional[List[str]] = None):
        """Query data from a table with optional predicates asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.select, table_name, predicate, output_by_row, columns)
    
    # Async Batch Operations
    async def insert_batch_efficient_async(self, table_name: str, data: Dict[str, List[Any]], 
                                         batch_size: int = DEFAULT_BATCH_SIZE, max_workers: int = DEFAULT_MAX_WORKERS):
        """Insert large datasets efficiently asynchronously using row pooling and parallel processing"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.insert_batch_efficient, 
                                        table_name, data, batch_size, max_workers)
    
    async def insert_batch_transactional_async(self, table_name: str, data: Dict[str, List[Any]], 
                                             batch_size: int = DEFAULT_BATCH_SIZE, max_workers: int = DEFAULT_MAX_WORKERS, 
                                             max_retries: int = DEFAULT_MAX_RETRIES, enable_rollback: bool = True):
        """Insert data with transactional safety asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.insert_batch_transactional,
                                        table_name, data, batch_size, max_workers, max_retries, enable_rollback)
    
    async def cleanup_partial_insertion_async(self, table_name: str, failed_batch_ids: List[str], 
                                            batch_details: Dict[str, Any]) -> bool:
        """Clean up partial insertions when batch operations fail asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.cleanup_partial_insertion, 
                                        table_name, failed_batch_ids, batch_details)
    
    # Async Analytics and Performance
    async def get_cache_stats_async(self) -> Dict[str, Any]:
        """Get cache statistics asynchronously"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get_cache_stats)
    
    async def clear_cache_async(self):
        """Clear all cached data asynchronously"""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.clear_cache)
    
    async def refresh_table_metadata_async(self, table_name: str):
        """Refresh table metadata in cache asynchronously"""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.refresh_table_metadata, table_name)
    
    async def close_async(self):
        """Cleanup resources asynchronously"""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.close)
    
    # Async Context Manager
    async def __aenter__(self):
        """Async context manager entry"""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.close_async()
