"""
S3 Object Management

This module provides object listing, copying, and advanced S3 operations
including presigned URL generation and bucket management.
"""

import logging
from typing import List, Dict, Any, Optional
from botocore.exceptions import ClientError

# S3Client will be passed as parameter

logger = logging.getLogger(__name__)


class S3ObjectManager:
    """
    Handles object management and advanced S3 operations
    
    This class provides functionality for:
    - Object listing and searching
    - Object copying within buckets
    - Presigned URL generation
    - Bucket information retrieval
    """
    
    def __init__(self, s3_client):
        """
        Initialize object manager
        
        Args:
            s3_client: S3Client instance for basic operations
        """
        self.s3_client = s3_client
        logger.debug("S3ObjectManager initialized")
    
    def list_objects(self, prefix: str = "", max_keys: int = 1000, bucket: Optional[str] = None) -> List[str]:
        """
        List objects in S3 with the specified prefix
        
        Args:
            prefix: Object key prefix to filter by
            max_keys: Maximum number of keys to return
            bucket: Bucket name. If None, uses bucket from config (if available)
            
        Returns:
            List[str]: List of object keys
        """
        target_bucket = bucket or self.s3_client.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_prefix = self.s3_client._build_key(prefix)
            response = self.s3_client.s3_client.list_objects_v2(
                Bucket=target_bucket,
                Prefix=full_prefix,
                MaxKeys=max_keys
            )
            
            if 'Contents' in response:
                keys = [obj['Key'] for obj in response['Contents']]
                logger.debug("Listed %d objects with prefix '%s'", len(keys), prefix)
                return keys
            else:
                logger.debug("No objects found with prefix '%s'", prefix)
                return []
                
        except Exception as e:
            logger.error("Failed to list objects with prefix '%s': %s", prefix, e)
            return []
    
    def copy_object(self, source_key: str, destination_key: str, bucket: Optional[str] = None) -> bool:
        """
        Copy an object within the same bucket
        
        Args:
            source_key: Source object key
            destination_key: Destination object key
            bucket: Bucket name. If None, uses bucket from config (if available)
            
        Returns:
            bool: True if copy successful, False otherwise
        """
        target_bucket = bucket or self.s3_client.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_source_key = self.s3_client._build_key(source_key)
            full_destination_key = self.s3_client._build_key(destination_key)
            
            copy_source = {
                'Bucket': target_bucket,
                'Key': full_source_key
            }
            
            self.s3_client.s3_client.copy_object(
                CopySource=copy_source,
                Bucket=target_bucket,
                Key=full_destination_key
            )
            
            logger.debug("Copied object: %s -> %s", source_key, destination_key)
            return True
            
        except Exception as e:
            logger.error("Failed to copy object %s to %s: %s", source_key, destination_key, e)
            return False
    
    def generate_presigned_url(self, key: str, operation: str = "get_object", 
                             expiration: int = 3600, bucket: Optional[str] = None,
                             content_type: Optional[str] = None, 
                             response_content_type: Optional[str] = None,
                             response_content_disposition: Optional[str] = None,
                             extra_params: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """
        Generate a presigned URL for an S3 object
        
        Args:
            key: S3 object key
            operation: S3 operation (get_object, put_object, etc.)
            expiration: URL expiration time in seconds
            bucket: Bucket name. If None, uses bucket from config (if available)
            content_type: MIME type for PUT operations (ContentType parameter)
            response_content_type: MIME type for GET operations (ResponseContentType parameter)
            response_content_disposition: Content disposition for GET operations (e.g., 'attachment; filename="file.mp4"')
            extra_params: Additional boto3 parameters to include in presigned URL
            
        Returns:
            str: Presigned URL or None if failed
            
        Examples:
            # PUT with content-type
            url = client.generate_presigned_url(key, "put_object", content_type="video/mp2t")
            
            # GET with response content-type
            url = client.generate_presigned_url(key, "get_object", response_content_type="video/mp2t")
            
            # GET with content-type and disposition
            url = client.generate_presigned_url(
                key, 
                "get_object", 
                response_content_type="video/mp2t",
                response_content_disposition='attachment; filename="video.mp4"'
            )
        """
        target_bucket = bucket or self.s3_client.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_key = self.s3_client._build_key(key)
            params: Dict[str, Any] = {'Bucket': target_bucket, 'Key': full_key}
            if content_type and operation == "put_object":
                params['ContentType'] = content_type
            if response_content_type and operation == "get_object":
                params['ResponseContentType'] = response_content_type
            if response_content_disposition and operation == "get_object":
                params['ResponseContentDisposition'] = response_content_disposition
            if extra_params:
                params.update(extra_params)
            
            url = self.s3_client.s3_client.generate_presigned_url(
                operation,
                Params=params,
                ExpiresIn=expiration
            )
            
            logger.debug("Generated presigned URL for %s (expires in %d seconds)", key, expiration)
            return url
            
        except Exception as e:
            logger.error("Failed to generate presigned URL for %s: %s", key, e)
            return None
    
    def get_bucket_info(self, bucket: Optional[str] = None) -> Dict[str, Any]:
        """
        Get information about the S3 bucket
        
        Args:
            bucket: Bucket name. If None, uses bucket from config (if available)
            
        Returns:
            Dict: Bucket information
        """
        target_bucket = bucket or self.s3_client.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            # Get bucket location
            location_response = self.s3_client.s3_client.get_bucket_location(
                Bucket=target_bucket
            )
            
            # Get bucket versioning status
            try:
                versioning_response = self.s3_client.s3_client.get_bucket_versioning(
                    Bucket=target_bucket
                )
                versioning_status = versioning_response.get('Status', 'Disabled')
            except ClientError:
                versioning_status = 'Unknown'
            
            # Get bucket policy
            try:
                self.s3_client.s3_client.get_bucket_policy(
                    Bucket=target_bucket
                )
                has_policy = True
            except ClientError:
                has_policy = False
            
            # Get bucket ACL
            try:
                acl_response = self.s3_client.s3_client.get_bucket_acl(
                    Bucket=target_bucket
                )
                owner = acl_response.get('Owner', {})
            except ClientError:
                owner = {}
            
            bucket_info = {
                'name': self.s3_client.bucket_name,
                'region': location_response.get('LocationConstraint', 'us-east-1'),
                'versioning': versioning_status,
                'has_policy': has_policy,
                'owner': owner,
                'endpoint': self.s3_client.endpoint_url,
                'key_prefix': self.s3_client.key_prefix
            }
            
            logger.debug("Retrieved bucket info for %s", self.s3_client.bucket_name)
            return bucket_info
            
        except Exception as e:
            logger.error("Failed to get bucket info: %s", e)
            return {
                'name': self.s3_client.bucket_name,
                'error': str(e)
            }
    
    def list_objects_with_metadata(self, prefix: str = "", max_keys: int = 1000, bucket: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List objects with their metadata
        
        Args:
            prefix: Object key prefix to filter by
            max_keys: Maximum number of keys to return
            bucket: Bucket name. If None, uses bucket from config (if available)
            
        Returns:
            List[Dict]: List of objects with metadata
        """
        target_bucket = bucket or self.s3_client.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            full_prefix = self.s3_client._build_key(prefix)
            response = self.s3_client.s3_client.list_objects_v2(
                Bucket=target_bucket,
                Prefix=full_prefix,
                MaxKeys=max_keys
            )
            
            if 'Contents' in response:
                objects = []
                for obj in response['Contents']:
                    objects.append({
                        'key': obj['Key'],
                        'size': obj['Size'],
                        'last_modified': obj['LastModified'],
                        'etag': obj['ETag'],
                        'storage_class': obj.get('StorageClass', 'STANDARD')
                    })
                
                logger.debug("Listed %d objects with metadata for prefix '%s'", len(objects), prefix)
                return objects
            else:
                logger.debug("No objects found with prefix '%s'", prefix)
                return []
                
        except Exception as e:
            logger.error("Failed to list objects with metadata for prefix '%s': %s", prefix, e)
            return []
    
    def delete_objects(self, keys: List[str], bucket: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete multiple objects
        
        Args:
            keys: List of object keys to delete
            bucket: Bucket name. If None, uses bucket from config (if available)
            
        Returns:
            Dict: Deletion results
        """
        target_bucket = bucket or self.s3_client.bucket_name
        if not target_bucket:
            raise ValueError(
                "No bucket specified. Either provide 'bucket' parameter or set 'bucket_name' in S3Config"
            )
        
        try:
            if not keys:
                return {'deleted': [], 'errors': []}
            
            # Build delete objects request
            objects_to_delete = []
            for key in keys:
                full_key = self.s3_client._build_key(key)
                objects_to_delete.append({'Key': full_key})
            
            response = self.s3_client.s3_client.delete_objects(
                Bucket=target_bucket,
                Delete={
                    'Objects': objects_to_delete
                }
            )
            
            deleted = [obj['Key'] for obj in response.get('Deleted', [])]
            errors = response.get('Errors', [])
            
            logger.info("Deleted %d objects (%d errors)", len(deleted), len(errors))
            return {
                'deleted': deleted,
                'errors': errors
            }
            
        except Exception as e:
            logger.error("Failed to delete objects: %s", e)
            return {
                'deleted': [],
                'errors': [{'Key': key, 'Code': 'Unknown', 'Message': str(e)} for key in keys]
            }
